<?php

namespace EspritEntraideBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EspritEntraideBundle extends Bundle
{
}
