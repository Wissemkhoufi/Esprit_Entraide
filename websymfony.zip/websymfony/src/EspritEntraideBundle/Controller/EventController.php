<?php

namespace EspritEntraideBundle\Controller;

use EspritEntraideBundle\Entity\Event;
use EspritEntraideBundle\Entity\Rate;
use EspritEntraideBundle\Form\EventType;
use EspritEntraideBundle\Form\RateType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class EventController extends Controller
{



    public function addAdminAction(Request $request)
    {
        $cl = new Event();
        $form = $this->createForm(EventType::class, $cl);
        $form->handleRequest($request);/*creation d'une session pr stocker les valeurs de l'input*/
        if ($form->isValid()) {
            $cl->setUser($this->getUser());
            $em = $this->getDoctrine()->getManager();
            $em->persist($cl);
            $em->flush();
            return $this->redirectToRoute('list_event');
        }
        return $this->render('EspritEntraideBundle:admin/Event:add.html.twig', array(
            'form' => $form->createView()
        ));
    }

    public function addAction(Request $request)
    {
        $ev = new Event();
        $form = $this->createForm(EventType::class, $ev);
        $form->handleRequest($request);/*creation d'une session pr stocker les valeurs de l'input*/
        if ($form->isValid()) {
            $ev->setUser($this->getUser());
            $em = $this->getDoctrine()->getManager();
            $em->persist($ev);
            $em->flush();
            return $this->redirectToRoute('list_user_event');
        }
        return $this->render('EspritEntraideBundle:user/Event:add.html.twig', array(
            'form' => $form->createView()
        ));
    }

    public function listAdminAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $events = $em->getRepository("EspritEntraideBundle:Event")->findAll();
        return $this->render('EspritEntraideBundle:admin/Event:list.html.twig', array(
            "events" => $events
        ));
    }

    public function ajaxrateAction(Request $request){

        if($request->isXmlHttpRequest()){
            $em = $this->getDoctrine()->getManager();
            $value = $request->get('rating');
            $event = $request->get('event');
            $rateEx = $em->getRepository("EspritEntraideBundle:Rate")->findBy(array(
                'event'=>$event,
                'user'=>$this->getUser()
                ));
            if($rateEx){
                return new JsonResponse(array('message'=>'rating already created'));
            }else{
                $eventEntity = $em->getRepository("EspritEntraideBundle:Event")->find($event);

                $rate = new Rate();
                $rate->setRating( $value);
                $rate->setEvent( $eventEntity);
                $rate->setUser($this->getUser());
                $em->persist($rate);
                $em->flush();
                return new JsonResponse(array('message'=>'rating created'));
            }



        }
    }

    public function showAction(Request $request){

        return $this->render('EspritEntraideBundle:user/Event:search.html.twig');
    }

    public function searchAction(Request $request){

        if($request->isXmlHttpRequest()){
            $attribute = $request->get('attribute');
            $value = $request->get('value');
            $em = $this->getDoctrine()->getManager();
            $events = $em->getRepository("EspritEntraideBundle:Event")
                ->searchLike($attribute, $value);
            return new JsonResponse(array('events'=>$events));

        }
    }

    public function listAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $rate = new Rate();

        $form = $this->createForm(RateType::class, $rate);
        $events = $em->getRepository("EspritEntraideBundle:Event")->findAll();
        $arrayForms = array();
        foreach ($events as $event)
        {
            $form_view = $form->createView();
            $arrayForms[] = $form_view;
        }
        return $this->render('EspritEntraideBundle:user/Event:list.html.twig', array(
            "events" => $events,
            "forms"=>$arrayForms
        ));
    }

    public function mylistAction()
    {
        $em = $this->getDoctrine()->getManager();
        $events = $em->getRepository("EspritEntraideBundle:Event")->findBy(array('user' => $this->getUser()));
        return $this->render('EspritEntraideBundle:user/Event:mylist.html.twig', array(
            "events" => $events
        ));
    }

    public function editAction(Request $request, $id)
    {


        $em = $this->getDoctrine()->getManager();
        $ev = $em->getRepository('EspritEntraideBundle:Event')->find($id);
        $form = $this->createForm(EventType::class, $ev);
        $form->handleRequest($request);

        if($form->isValid()){
            $em->persist($ev);
            $em->flush();
            return $this->redirectToRoute('mylist_user_event');
        }

        return $this->render('EspritEntraideBundle:user/Event:edit.html.twig', array('form'=>$form->createView()));
    }

    public function editAdminAction(Request $request)
    {

        $id = $request->get('id');

        $em = $this->getDoctrine()->getManager();
        $ev = $em->getRepository('EspritEntraideBundle:Event')->find($id);
        $form = $this->createForm(EventType::class, $ev);
        $form->handleRequest($request);

        if($form->isValid()){
            $em->persist($ev);
            $em->flush();
            return $this->redirectToRoute('list_event');
        }

        return $this->render('EspritEntraideBundle:admin/Event:edit.html.twig', array('form'=>$form->createView()));
    }

    function deleteAction(Request $request,$id){
        $em = $this->getDoctrine()->getManager();
        $ev = $em->getRepository('EspritEntraideBundle:Event')->find($id);
        $form = $this->createForm(EventType::class, $ev);
        $form->handleRequest($request);
        $em->remove($ev);
        $em->flush();
        return $this->redirectToRoute('mylist_user_event');
    }

    function deleteAdminAction(Request $request){
        $id = $request->get('id');
        $cl=$this->getDoctrine()->getManager();
        $event=$cl->getRepository("EspritEntraideBundle:Event")->find($id);
        $form=$this->createForm(EventType::class,$event);
        $form->handleRequest($request);
        $cl->remove($event);
        $cl->flush();
        return $this->redirectToRoute('list_event');
    }




}
