<?php

namespace EspritEntraideBundle\Controller;

use EspritEntraideBundle\EspritEntraideBundle;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use EspritEntraideBundle\Entity\User;

class AdminController extends Controller
{
    public function adminAction(){

        return $this->render('EspritEntraideBundle:admin:home.html.twig');
    }

}
