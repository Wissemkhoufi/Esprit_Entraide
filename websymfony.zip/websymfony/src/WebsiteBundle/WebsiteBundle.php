<?php

namespace WebsiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WebsiteBundle extends Bundle
{
}
