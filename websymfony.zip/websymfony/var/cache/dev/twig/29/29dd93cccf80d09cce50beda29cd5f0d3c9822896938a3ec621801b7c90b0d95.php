<?php

/* EspritEntraideBundle:admin/Event:add.html.twig */
class __TwigTemplate_09ecb8e65f04d67e1f284d62c0140efd9d3569bf5dfbda4aad69cc75e769fb0d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("EspritEntraideBundle::layoutadmin.html.twig", "EspritEntraideBundle:admin/Event:add.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "EspritEntraideBundle::layoutadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:admin/Event:add.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:admin/Event:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Evenement";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <style type=\"text/css\">
        .important {
            color: #336699;
        }

        .big-div {
            padding: 8px !important;
        }

        .pos {
            background-color: #eee;
            margin: 5% auto 15% auto;
            border: 1px solid #888;
            width: 62%;
            border-radius: 10px;
        }
    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 23
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 24
        echo "
    ";
        // line 25
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
            // line 26
            echo "        <div class=\"page-wrapper\">
            <!-- Bread crumb -->
            <div class=\"row page-titles\">
                <div class=\"col-md-5 align-self-center\">
                    <h3 class=\"text-primary\">Dashboard</h3></div>
                <div class=\"col-md-7 align-self-center\">
                    <ol class=\"breadcrumb\">
                        <li class=\"breadcrumb-item\"><a href=\"javascript:void(0)\">Evenement</a></li>
                        <li class=\"breadcrumb-item active\">Ajout</li>
                    </ol>
                </div>
            </div>
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title\">Evenement</h4>
                    ";
            // line 41
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
            echo "
                    ";
            // line 42
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            echo "
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 45
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'label', array("label" => "Nom"));
            echo "
                            ";
            // line 46
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'errors');
            echo "
                            ";
            // line 47
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "nom club")));
            echo "

                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 53
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateDebut", array()), 'label', array("label" => "date debut"));
            echo "
                            ";
            // line 54
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateDebut", array()), 'errors');
            echo "
                            ";
            // line 55
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateDebut", array()), 'widget', array("attr" => array("class" => "form-control datepicker", "placeholder" => "date debut du l'evenement")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 60
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureDebut", array()), 'label', array("label" => "heure Debut timepicker"));
            echo "
                            ";
            // line 61
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureDebut", array()), 'errors');
            echo "
                            ";
            // line 62
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureDebut", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "heure debut de l'evenement ")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 67
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateFin", array()), 'label', array("label" => "date fin"));
            echo "
                            ";
            // line 68
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateFin", array()), 'errors');
            echo "
                            ";
            // line 69
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateFin", array()), 'widget', array("attr" => array("class" => "form-control datepicker", "placeholder" => "date fin de l'evenement ")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 74
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureFin", array()), 'label', array("label" => "heure fin"));
            echo "
                            ";
            // line 75
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureFin", array()), 'errors');
            echo "
                            ";
            // line 76
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureFin", array()), 'widget', array("attr" => array("class" => "form-control timepicker", "placeholder" => "heure fin de l'evenement ")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 81
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'label', array("label" => "description"));
            echo "
                            ";
            // line 82
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'errors');
            echo "
                            ";
            // line 83
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "description de l'evenement ")));
            echo "
                        </div>
                    </div>
                    <button type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\">Submit</button>
                    ";
            // line 87
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
            echo "
                </div>
            </div>
            <footer class=\"footer\"> © 2018 All rights reserved. Template designed by <a
                        href=\"https://colorlib.com\">Colorlib</a></footer>
        </div>

    ";
        } else {
            // line 95
            echo "        <center><h1>You should <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">Login</a> or <a
                        href=\"";
            // line 96
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
            echo "\">Register</a> :) </h1></center>
    ";
        }
        // line 98
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 102
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 103
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script>
        \$(document).ready(function() {
            \$('.datepicker').datepicker();
            \$('.timepicker').timepicker();
        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "EspritEntraideBundle:admin/Event:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  278 => 103,  269 => 102,  258 => 98,  253 => 96,  248 => 95,  237 => 87,  230 => 83,  226 => 82,  222 => 81,  214 => 76,  210 => 75,  206 => 74,  198 => 69,  194 => 68,  190 => 67,  182 => 62,  178 => 61,  174 => 60,  166 => 55,  162 => 54,  158 => 53,  149 => 47,  145 => 46,  141 => 45,  135 => 42,  131 => 41,  114 => 26,  112 => 25,  109 => 24,  100 => 23,  70 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'EspritEntraideBundle::layoutadmin.html.twig' %}
{% block title %}Evenement{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <style type=\"text/css\">
        .important {
            color: #336699;
        }

        .big-div {
            padding: 8px !important;
        }

        .pos {
            background-color: #eee;
            margin: 5% auto 15% auto;
            border: 1px solid #888;
            width: 62%;
            border-radius: 10px;
        }
    </style>
{% endblock %}
{% block content %}

    {% if(is_granted('ROLE_ADMIN')) %}
        <div class=\"page-wrapper\">
            <!-- Bread crumb -->
            <div class=\"row page-titles\">
                <div class=\"col-md-5 align-self-center\">
                    <h3 class=\"text-primary\">Dashboard</h3></div>
                <div class=\"col-md-7 align-self-center\">
                    <ol class=\"breadcrumb\">
                        <li class=\"breadcrumb-item\"><a href=\"javascript:void(0)\">Evenement</a></li>
                        <li class=\"breadcrumb-item active\">Ajout</li>
                    </ol>
                </div>
            </div>
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title\">Evenement</h4>
                    {{ form_start(form) }}
                    {{ form_errors(form) }}
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.nom,'Nom') }}
                            {{ form_errors(form.nom) }}
                            {{ form_widget(form.nom,{'attr': {'class': 'form-control','placeholder': \"nom club\"}}) }}

                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.dateDebut,'date debut') }}
                            {{ form_errors(form.dateDebut) }}
                            {{ form_widget(form.dateDebut,{'attr': {'class': 'form-control datepicker','placeholder': \"date debut du l'evenement\"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.heureDebut,'heure Debut timepicker') }}
                            {{ form_errors(form.heureDebut) }}
                            {{ form_widget(form.heureDebut,{'attr': {'class': 'form-control','placeholder': \"heure debut de l'evenement \"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.dateFin,'date fin') }}
                            {{ form_errors(form.dateFin) }}
                            {{ form_widget(form.dateFin,{'attr': {'class': 'form-control datepicker','placeholder': \"date fin de l'evenement \"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.heureFin,'heure fin') }}
                            {{ form_errors(form.heureFin) }}
                            {{ form_widget(form.heureFin,{'attr': {'class': 'form-control timepicker','placeholder': \"heure fin de l'evenement \"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.description,'description') }}
                            {{ form_errors(form.description) }}
                            {{ form_widget(form.description,{'attr': {'class': 'form-control','placeholder': \"description de l'evenement \"}}) }}
                        </div>
                    </div>
                    <button type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\">Submit</button>
                    {{ form_end(form) }}
                </div>
            </div>
            <footer class=\"footer\"> © 2018 All rights reserved. Template designed by <a
                        href=\"https://colorlib.com\">Colorlib</a></footer>
        </div>

    {% else %}
        <center><h1>You should <a href=\"{{ path('fos_user_security_login') }}\">Login</a> or <a
                        href=\"{{ path('fos_user_registration_register') }}\">Register</a> :) </h1></center>
    {% endif %}

{% endblock %}


{% block javascripts %}
    {{ parent()}}
    <script>
        \$(document).ready(function() {
            \$('.datepicker').datepicker();
            \$('.timepicker').timepicker();
        });
    </script>
{% endblock %}", "EspritEntraideBundle:admin/Event:add.html.twig", "C:\\wamp64\\www\\EspritEntraide\\src\\EspritEntraideBundle/Resources/views/admin/Event/add.html.twig");
    }
}
