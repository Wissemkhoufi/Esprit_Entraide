<?php

/* EspritEntraideBundle:user/Event:add.html.twig */
class __TwigTemplate_0e8e5103065bcb335ff74caecfaf85aa2b67ae63ae82ed4e7cb00b9e17e01a5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("EspritEntraideBundle::layout.html.twig", "EspritEntraideBundle:user/Event:add.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'containt' => array($this, 'block_containt'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "EspritEntraideBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:user/Event:add.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:user/Event:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <style>
        .header-top-area{
            background-color:#1D3159;
        }
    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "ajout evenement!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_containt($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "containt"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "containt"));

        // line 13
        echo "
    ";
        // line 14
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 15
            echo "        <div class=\"page-wrapper\">

            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title\">Evenement</h4>
                    ";
            // line 20
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
            echo "
                    ";
            // line 21
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            echo "
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 24
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'label', array("label" => "Nom"));
            echo "
                            ";
            // line 25
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'errors');
            echo "
                            ";
            // line 26
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "nom event")));
            echo "

                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 32
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateDebut", array()), 'label', array("label" => "date debut"));
            echo "
                            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateDebut", array()), 'errors');
            echo "
                            ";
            // line 34
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateDebut", array()), 'widget', array("attr" => array("class" => "form-control datepicker", "placeholder" => "date debut du l'evenement")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 39
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureDebut", array()), 'label', array("label" => "heure Debut "));
            echo "
                            ";
            // line 40
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureDebut", array()), 'errors');
            echo "
                            ";
            // line 41
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureDebut", array()), 'widget', array("attr" => array("class" => "form-control timepicker", "placeholder" => "heure debut de l'evenement ")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 46
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateFin", array()), 'label', array("label" => "date fin"));
            echo "
                            ";
            // line 47
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateFin", array()), 'errors');
            echo "
                            ";
            // line 48
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "dateFin", array()), 'widget', array("attr" => array("class" => "form-control datepicker", "placeholder" => "date fin de l'evenement ")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 53
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureFin", array()), 'label', array("label" => "heure fin"));
            echo "
                            ";
            // line 54
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureFin", array()), 'errors');
            echo "
                            ";
            // line 55
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "heureFin", array()), 'widget', array("attr" => array("class" => "form-control timepicker", "placeholder" => "heure fin de l'evenement ")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 60
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'label', array("label" => "description"));
            echo "
                            ";
            // line 61
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'errors');
            echo "
                            ";
            // line 62
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "description de l'evenement ")));
            echo "
                        </div>
                    </div>
                    <button type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\">Submit</button>
                    ";
            // line 66
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
            echo "
                </div>
            </div>
            <footer class=\"footer\"> © 2018 All rights reserved. Template designed by <a
                        href=\"https://colorlib.com\">Colorlib</a></footer>
        </div>

    ";
        } else {
            // line 74
            echo "        <center><h1>You should <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">Login</a> or <a
                        href=\"";
            // line 75
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
            echo "\">Register</a> :) </h1></center>
    ";
        }
        // line 77
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 80
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 81
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/locales/bootstrap-datepicker.fr.min.js\"></script>
    <script>
        \$(document).ready(function() {
            console.log('date working')

        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "EspritEntraideBundle:user/Event:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  256 => 81,  247 => 80,  236 => 77,  231 => 75,  226 => 74,  215 => 66,  208 => 62,  204 => 61,  200 => 60,  192 => 55,  188 => 54,  184 => 53,  176 => 48,  172 => 47,  168 => 46,  160 => 41,  156 => 40,  152 => 39,  144 => 34,  140 => 33,  136 => 32,  127 => 26,  123 => 25,  119 => 24,  113 => 21,  109 => 20,  102 => 15,  100 => 14,  97 => 13,  88 => 12,  70 => 10,  52 => 3,  43 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'EspritEntraideBundle::layout.html.twig' %}
{% block stylesheets %}
    {{ parent() }}
    <style>
        .header-top-area{
            background-color:#1D3159;
        }
    </style>
{% endblock %}
{% block title %}ajout evenement!{% endblock %}

{% block containt %}

    {% if(is_granted('IS_AUTHENTICATED_FULLY')) %}
        <div class=\"page-wrapper\">

            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title\">Evenement</h4>
                    {{ form_start(form) }}
                    {{ form_errors(form) }}
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.nom,'Nom') }}
                            {{ form_errors(form.nom) }}
                            {{ form_widget(form.nom,{'attr': {'class': 'form-control','placeholder': \"nom event\"}}) }}

                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.dateDebut,'date debut') }}
                            {{ form_errors(form.dateDebut) }}
                            {{ form_widget(form.dateDebut,{'attr': {'class': 'form-control datepicker','placeholder': \"date debut du l'evenement\"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.heureDebut,'heure Debut ') }}
                            {{ form_errors(form.heureDebut) }}
                            {{ form_widget(form.heureDebut,{'attr': {'class': 'form-control timepicker','placeholder': \"heure debut de l'evenement \"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.dateFin,'date fin') }}
                            {{ form_errors(form.dateFin) }}
                            {{ form_widget(form.dateFin,{'attr': {'class': 'form-control datepicker','placeholder': \"date fin de l'evenement \"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.heureFin,'heure fin') }}
                            {{ form_errors(form.heureFin) }}
                            {{ form_widget(form.heureFin,{'attr': {'class': 'form-control timepicker','placeholder': \"heure fin de l'evenement \"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.description,'description') }}
                            {{ form_errors(form.description) }}
                            {{ form_widget(form.description,{'attr': {'class': 'form-control','placeholder': \"description de l'evenement \"}}) }}
                        </div>
                    </div>
                    <button type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\">Submit</button>
                    {{ form_end(form) }}
                </div>
            </div>
            <footer class=\"footer\"> © 2018 All rights reserved. Template designed by <a
                        href=\"https://colorlib.com\">Colorlib</a></footer>
        </div>

    {% else %}
        <center><h1>You should <a href=\"{{ path('fos_user_security_login') }}\">Login</a> or <a
                        href=\"{{ path('fos_user_registration_register') }}\">Register</a> :) </h1></center>
    {% endif %}

{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/locales/bootstrap-datepicker.fr.min.js\"></script>
    <script>
        \$(document).ready(function() {
            console.log('date working')

        });
    </script>
{% endblock %}", "EspritEntraideBundle:user/Event:add.html.twig", "C:\\wamp64\\www\\EspritEntraide\\src\\EspritEntraideBundle\\Resources\\views\\user\\Event\\add.html.twig");
    }
}
