<?php

/* EspritEntraideBundle:user/Event:search.html.twig */
class __TwigTemplate_653be99842c0cf77dd1da23531d92690d6e6c172c35c5778ee8d43c925c35dd7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("EspritEntraideBundle::layout.html.twig", "EspritEntraideBundle:user/Event:search.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'containt' => array($this, 'block_containt'),
            'javascripts' => array($this, 'block_javascripts'),
            'javascripts2' => array($this, 'block_javascripts2'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "EspritEntraideBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:user/Event:search.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:user/Event:search.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "liste Evenements!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <style>
        .header-top-area {
            background-color: #1D3159;
        }
    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_containt($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "containt"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "containt"));

        // line 13
        echo "    <div id=\"path\" data-path=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ajax_search_event");
        echo "\">
    </div>
    <div id=\"user\" data-user=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "id", array()), "html", null, true);
        echo "\">
    </div>

    <div>
        <div class=\"row\">
            <nav class=\"navbar navbar-light bg-light\">
                <form class=\"form-inline\">
                    <input class=\"form-control mr-sm-2 search\" type=\"text\" placeholder=\"Search\">
                </form>
            </nav>
            <div class=\"btn-group btn-group-sm\" data-toggle=\"buttons\">
                <div class=\"form-check\">
                    <input class=\"form-check-input\" value=\"nom\" name=\"searchterm\" type=\"radio\">
                    <label class=\"form-check-label\" for=\"radio100\">nom</label>
                    <input class=\"form-check-input\" value=\"dateDebut\" name=\"searchterm\" type=\"radio\" checked>
                    <label class=\"form-check-label\" for=\"radio101\">date debut</label>
                    <input class=\"form-check-input\" value=\"description\" name=\"searchterm\" type=\"radio\" id=\"radio102\">
                    <label class=\"form-check-label\" for=\"radio102\">description</label>
                </div>
            </div>
        </div>
        <div class=\"media text-muted pt-3 box-shadow \" id=\"clone1\" style=\"display:none\">
            <div class=\"media-body pb-3 mb-0 small lh-125 border-bottom border-gray\">
                <div class=\"d-flex justify-content-between align-items-center w-100\">
                    <h4 class=\"text-gray-dark\">
                        <span class=\"nom\">text1</span></h4>
                    <div><strong>date de debut : </strong><span class=\"dateDebut\"></span></div>
                    <div><strong>date de fin : </strong><span class=\"dateFin\"></span></div>
                </div>
                <div datetime=\"2017-06-06\"><strong>description : </strong><span class=\"description\"></span></div>
            </div>

        </div>
        <div class=\"my-3 p-3 bg-white rounded box-shadow\">
            <h6 class=\"border-bottom border-gray pb-2 mb-0\">Evenements</h6>
        </div>
        <div class=\"container_events\">

        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 57
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 58
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 61
    public function block_javascripts2($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts2"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts2"));

        // line 62
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/js/search_event.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "EspritEntraideBundle:user/Event:search.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  186 => 62,  177 => 61,  164 => 58,  155 => 57,  104 => 15,  98 => 13,  89 => 12,  71 => 5,  62 => 4,  44 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'EspritEntraideBundle::layout.html.twig' %}

{% block title %}liste Evenements!{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <style>
        .header-top-area {
            background-color: #1D3159;
        }
    </style>
{% endblock %}
{% block containt %}
    <div id=\"path\" data-path=\"{{ path('ajax_search_event') }}\">
    </div>
    <div id=\"user\" data-user=\"{{ app.user.id }}\">
    </div>

    <div>
        <div class=\"row\">
            <nav class=\"navbar navbar-light bg-light\">
                <form class=\"form-inline\">
                    <input class=\"form-control mr-sm-2 search\" type=\"text\" placeholder=\"Search\">
                </form>
            </nav>
            <div class=\"btn-group btn-group-sm\" data-toggle=\"buttons\">
                <div class=\"form-check\">
                    <input class=\"form-check-input\" value=\"nom\" name=\"searchterm\" type=\"radio\">
                    <label class=\"form-check-label\" for=\"radio100\">nom</label>
                    <input class=\"form-check-input\" value=\"dateDebut\" name=\"searchterm\" type=\"radio\" checked>
                    <label class=\"form-check-label\" for=\"radio101\">date debut</label>
                    <input class=\"form-check-input\" value=\"description\" name=\"searchterm\" type=\"radio\" id=\"radio102\">
                    <label class=\"form-check-label\" for=\"radio102\">description</label>
                </div>
            </div>
        </div>
        <div class=\"media text-muted pt-3 box-shadow \" id=\"clone1\" style=\"display:none\">
            <div class=\"media-body pb-3 mb-0 small lh-125 border-bottom border-gray\">
                <div class=\"d-flex justify-content-between align-items-center w-100\">
                    <h4 class=\"text-gray-dark\">
                        <span class=\"nom\">text1</span></h4>
                    <div><strong>date de debut : </strong><span class=\"dateDebut\"></span></div>
                    <div><strong>date de fin : </strong><span class=\"dateFin\"></span></div>
                </div>
                <div datetime=\"2017-06-06\"><strong>description : </strong><span class=\"description\"></span></div>
            </div>

        </div>
        <div class=\"my-3 p-3 bg-white rounded box-shadow\">
            <h6 class=\"border-bottom border-gray pb-2 mb-0\">Evenements</h6>
        </div>
        <div class=\"container_events\">

        </div>
    </div>
{% endblock %}

{% block javascripts %}
    {{ parent() }}
{% endblock %}

{% block javascripts2 %}
    <script src=\"{{ asset('user/js/search_event.js') }}\"></script>
{% endblock %}", "EspritEntraideBundle:user/Event:search.html.twig", "C:\\wamp64\\www\\EspritEntraide\\src\\EspritEntraideBundle\\Resources\\views\\user\\Event\\search.html.twig");
    }
}
