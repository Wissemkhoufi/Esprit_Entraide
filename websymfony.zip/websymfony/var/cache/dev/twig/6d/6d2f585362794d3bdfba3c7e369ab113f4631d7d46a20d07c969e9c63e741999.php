<?php

/* EspritEntraideBundle:user/Club:mylist.html.twig */
class __TwigTemplate_ee7ce62aaf28ab51c9d2668806cafe170f93aa49ec72d5e2354af02a9fc9af8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("EspritEntraideBundle::layout.html.twig", "EspritEntraideBundle:user/Club:mylist.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'containt' => array($this, 'block_containt'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "EspritEntraideBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:user/Club:mylist.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:user/Club:mylist.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "liste clubs!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <style>
        .header-top-area {
            background-color: #1D3159;
        }
    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_containt($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "containt"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "containt"));

        // line 13
        echo "    <div>
        <div class=\"my-3 p-3 bg-white rounded box-shadow\">
            <h6 class=\"border-bottom border-gray pb-2 mb-0\">Clubs</h6>
        </div>
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["clubs"] ?? $this->getContext($context, "clubs")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 18
            echo "            <div class=\"media text-muted pt-3 box-shadow\">
                <div class=\"media-body pb-3 mb-0 small lh-125 border-bottom border-gray\">
                    <div class=\"d-flex justify-content-between align-items-center w-100\">
                        <h4 class=\"text-gray-dark\">";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["c"], "nom", array()), "html", null, true);
            echo "</h4>
                        <div><strong>date de creation : </strong>";
            // line 22
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["c"], "dateCreation", array()), "m/d/Y"), "html", null, true);
            echo "</div>
                        <div><strong>type du club :</strong> ";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["c"], "type", array()), "html", null, true);
            echo "</div>
                    </div>
                    <div class=\"tg-adtitle\">
                        <span><strong>conseiller pedagogique :</strong><a
                                    href=\"javascript:void(0);\">";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["c"], "conseillerPedagogique", array()), "html", null, true);
            echo "</a></span>
                    </div>
                    <span class=\"d-block\"> <strong>utilisateur : </strong> @";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["c"], "user", array()), "html", null, true);
            echo "</span>
                    <div datetime=\"2017-06-06\"><strong>description : </strong> ";
            // line 30
            echo $this->getAttribute($context["c"], "description", array());
            echo "</div>
                </div>
                <div class=\"pull-right\">
                    <a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit_user_club", array("id" => $this->getAttribute($context["c"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary btn-lg active\" role=\"button\" aria-pressed=\"true\">modifier</a>
                    <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_user_club", array("id" => $this->getAttribute($context["c"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-secondary btn-lg active\" role=\"button\" aria-pressed=\"true\">supprimer</a>
                </div>
            </div>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "EspritEntraideBundle:user/Club:mylist.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 39,  145 => 34,  141 => 33,  135 => 30,  131 => 29,  126 => 27,  119 => 23,  115 => 22,  111 => 21,  106 => 18,  102 => 17,  96 => 13,  87 => 12,  69 => 5,  60 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'EspritEntraideBundle::layout.html.twig' %}

{% block title %}liste clubs!{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <style>
        .header-top-area {
            background-color: #1D3159;
        }
    </style>
{% endblock %}
{% block containt %}
    <div>
        <div class=\"my-3 p-3 bg-white rounded box-shadow\">
            <h6 class=\"border-bottom border-gray pb-2 mb-0\">Clubs</h6>
        </div>
        {% for c in clubs %}
            <div class=\"media text-muted pt-3 box-shadow\">
                <div class=\"media-body pb-3 mb-0 small lh-125 border-bottom border-gray\">
                    <div class=\"d-flex justify-content-between align-items-center w-100\">
                        <h4 class=\"text-gray-dark\">{{ c.nom }}</h4>
                        <div><strong>date de creation : </strong>{{ c.dateCreation|date(\"m/d/Y\") }}</div>
                        <div><strong>type du club :</strong> {{ c.type }}</div>
                    </div>
                    <div class=\"tg-adtitle\">
                        <span><strong>conseiller pedagogique :</strong><a
                                    href=\"javascript:void(0);\">{{ c.conseillerPedagogique }}</a></span>
                    </div>
                    <span class=\"d-block\"> <strong>utilisateur : </strong> @{{ c.user }}</span>
                    <div datetime=\"2017-06-06\"><strong>description : </strong> {{ c.description|raw }}</div>
                </div>
                <div class=\"pull-right\">
                    <a href=\"{{ path('edit_user_club', { 'id': c.id }) }}\" class=\"btn btn-primary btn-lg active\" role=\"button\" aria-pressed=\"true\">modifier</a>
                    <a href=\"{{ path('delete_user_club', { 'id': c.id }) }}\" class=\"btn btn-secondary btn-lg active\" role=\"button\" aria-pressed=\"true\">supprimer</a>
                </div>
            </div>

        {% endfor %}
    </div>
{% endblock %}", "EspritEntraideBundle:user/Club:mylist.html.twig", "C:\\wamp64\\www\\EspritEntraide\\src\\EspritEntraideBundle\\Resources\\views\\user\\Club\\mylist.html.twig");
    }
}
