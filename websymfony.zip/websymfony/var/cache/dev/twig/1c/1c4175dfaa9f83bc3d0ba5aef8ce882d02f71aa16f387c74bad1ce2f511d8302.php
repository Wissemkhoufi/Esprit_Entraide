<?php

/* EspritEntraideBundle:admin/Club:add.html.twig */
class __TwigTemplate_4675e535ec89f623e38541d8805fb28424cb0099477fc5dbe62ebcbce500a123 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("EspritEntraideBundle::layoutadmin.html.twig", "EspritEntraideBundle:admin/Club:add.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "EspritEntraideBundle::layoutadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:admin/Club:add.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle:admin/Club:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Club";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <style type=\"text/css\">
        .important {
            color: #336699;
        }

        .big-div {
            padding: 8px !important;
        }

        .pos {
            background-color: #eee;
            margin: 5% auto 15% auto;
            border: 1px solid #888;
            width: 62%;
            border-radius: 10px;
        }
    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 24
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 25
        echo "
    ";
        // line 26
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
            // line 27
            echo "        <div class=\"page-wrapper\">
            <!-- Bread crumb -->
            <div class=\"row page-titles\">
                <div class=\"col-md-5 align-self-center\">
                    <h3 class=\"text-primary\">Dashboard</h3></div>
                <div class=\"col-md-7 align-self-center\">
                    <ol class=\"breadcrumb\">
                        <li class=\"breadcrumb-item\"><a href=\"javascript:void(0)\">Home</a></li>
                        <li class=\"breadcrumb-item active\">Dashboard</li>
                    </ol>
                </div>
            </div>
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title\">Club</h4>
                    ";
            // line 42
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
            echo "
                    ";
            // line 43
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            echo "
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 46
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'label', array("label" => "Titre"));
            echo "
                            ";
            // line 47
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'errors');
            echo "
                            ";
            // line 48
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "nom", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "titre club")));
            echo "

                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 54
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "conseillerPedagogique", array()), 'label', array("label" => "conseiller Pedagogique"));
            echo "
                            ";
            // line 55
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "conseillerPedagogique", array()), 'errors');
            echo "
                            ";
            // line 56
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "conseillerPedagogique", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "conseiller Pedagogique du club")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 61
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), 'label', array("label" => "type"));
            echo "
                            ";
            // line 62
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), 'errors');
            echo "
                            ";
            // line 63
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "type", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "type du club")));
            echo "
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            ";
            // line 68
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'label', array("label" => "description"));
            echo "
                            ";
            // line 69
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'errors');
            echo "
                            ";
            // line 70
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "description du club")));
            echo "
                        </div>
                    </div>

                    <button type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\">Submit</button>
                    ";
            // line 75
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
            echo "
                </div>
            </div>
            <footer class=\"footer\"> © 2018 All rights reserved. Template designed by <a
                        href=\"https://colorlib.com\">Colorlib</a></footer>
        </div>

    ";
        } else {
            // line 83
            echo "        <center><h1>You should <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">Login</a> or <a
                        href=\"";
            // line 84
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
            echo "\">Register</a> :) </h1></center>
    ";
        }
        // line 86
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "EspritEntraideBundle:admin/Club:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 86,  221 => 84,  216 => 83,  205 => 75,  197 => 70,  193 => 69,  189 => 68,  181 => 63,  177 => 62,  173 => 61,  165 => 56,  161 => 55,  157 => 54,  148 => 48,  144 => 47,  140 => 46,  134 => 43,  130 => 42,  113 => 27,  111 => 26,  108 => 25,  99 => 24,  69 => 5,  60 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'EspritEntraideBundle::layoutadmin.html.twig' %}

{% block title %}Club{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <style type=\"text/css\">
        .important {
            color: #336699;
        }

        .big-div {
            padding: 8px !important;
        }

        .pos {
            background-color: #eee;
            margin: 5% auto 15% auto;
            border: 1px solid #888;
            width: 62%;
            border-radius: 10px;
        }
    </style>
{% endblock %}
{% block content %}

    {% if(is_granted('ROLE_ADMIN')) %}
        <div class=\"page-wrapper\">
            <!-- Bread crumb -->
            <div class=\"row page-titles\">
                <div class=\"col-md-5 align-self-center\">
                    <h3 class=\"text-primary\">Dashboard</h3></div>
                <div class=\"col-md-7 align-self-center\">
                    <ol class=\"breadcrumb\">
                        <li class=\"breadcrumb-item\"><a href=\"javascript:void(0)\">Home</a></li>
                        <li class=\"breadcrumb-item active\">Dashboard</li>
                    </ol>
                </div>
            </div>
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title\">Club</h4>
                    {{ form_start(form) }}
                    {{ form_errors(form) }}
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.nom,'Titre') }}
                            {{ form_errors(form.nom) }}
                            {{ form_widget(form.nom,{'attr': {'class': 'form-control','placeholder': \"titre club\"}}) }}

                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.conseillerPedagogique,'conseiller Pedagogique') }}
                            {{ form_errors(form.conseillerPedagogique) }}
                            {{ form_widget(form.conseillerPedagogique,{'attr': {'class': 'form-control','placeholder': \"conseiller Pedagogique du club\"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.type,'type') }}
                            {{ form_errors(form.type) }}
                            {{ form_widget(form.type,{'attr': {'class': 'form-control','placeholder': \"type du club\"}}) }}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            {{ form_label(form.description,'description') }}
                            {{ form_errors(form.description) }}
                            {{ form_widget(form.description,{'attr': {'class': 'form-control','placeholder': \"description du club\"}}) }}
                        </div>
                    </div>

                    <button type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\">Submit</button>
                    {{ form_end(form) }}
                </div>
            </div>
            <footer class=\"footer\"> © 2018 All rights reserved. Template designed by <a
                        href=\"https://colorlib.com\">Colorlib</a></footer>
        </div>

    {% else %}
        <center><h1>You should <a href=\"{{ path('fos_user_security_login') }}\">Login</a> or <a
                        href=\"{{ path('fos_user_registration_register') }}\">Register</a> :) </h1></center>
    {% endif %}

{% endblock %}", "EspritEntraideBundle:admin/Club:add.html.twig", "C:\\wamp64\\www\\EspritEntraide\\src\\EspritEntraideBundle/Resources/views/admin/Club/add.html.twig");
    }
}
