<?php

/* EspritEntraideBundle::layoutadmin.html.twig */
class __TwigTemplate_a610b42fa25f456ad09d1c64cff2b8e333474c34e4811415d5a45a9d456c2ac4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle::layoutadmin.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle::layoutadmin.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>

    ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 9
        echo "

    ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 33
        echo "



    <![endif]-->
</head>

<body class=\"fix-header fix-sidebar\">
<!-- Preloader - style you can find in spinners.css -->
<div class=\"preloader\">
    <svg class=\"circular\" viewBox=\"25 25 50 50\">
        <circle class=\"path\" cx=\"50\" cy=\"50\" r=\"20\" fill=\"none\" stroke-width=\"2\" stroke-miterlimit=\"10\" /> </svg>
</div>
<!-- Main wrapper  -->
<div id=\"main-wrapper\">
    <!-- header header  -->
    <div class=\"header\">
        <nav class=\"navbar top-navbar navbar-expand-md navbar-light\">
            <!-- Logo -->
            <div class=\"navbar-header\">
                <a class=\"navbar-brand\" href=\"index.html\">
                    <!-- Logo icon -->
                    <b><img src=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/logo.png"), "html", null, true);
        echo "\" alt=\"homepage\" class=\"dark-logo\" /></b>
                    <!--End Logo icon -->
                    <!-- Logo text -->
                    <span><img src=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/logo-text.png"), "html", null, true);
        echo "\" alt=\"homepage\" class=\"dark-logo\" /></span>
                </a>
            </div>
            <!-- End Logo -->
            <div class=\"navbar-collapse\">
                <!-- toggle and nav items -->
                <ul class=\"navbar-nav mr-auto mt-md-0\">
                    <!-- This is  -->
                    <li class=\"nav-item\"> <a class=\"nav-link nav-toggler hidden-md-up text-muted  \" href=\"javascript:void(0)\"><i class=\"mdi mdi-menu\"></i></a> </li>
                    <li class=\"nav-item m-l-10\"> <a class=\"nav-link sidebartoggler hidden-sm-down text-muted  \" href=\"javascript:void(0)\"><i class=\"ti-menu\"></i></a> </li>
                    <!-- Messages -->

                    <!-- End Messages -->
                </ul>
                <!-- User profile and search -->
                <ul class=\"navbar-nav my-lg-0\">

                    <!-- Search -->
                    <li class=\"nav-item hidden-sm-down search-box\"> <a class=\"nav-link hidden-sm-down text-muted  \" href=\"javascript:void(0)\"><i class=\"ti-search\"></i></a>
                        <form class=\"app-search\">
                            <input type=\"text\" class=\"form-control\" placeholder=\"Search here\"> <a class=\"srh-btn\"><i class=\"ti-close\"></i></a> </form>
                    </li>
                    <!-- Comment -->
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle text-muted text-muted  \" href=\"#\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"> <i class=\"fa fa-bell\"></i>
                            <div class=\"notify\"> <span class=\"heartbit\"></span> <span class=\"point\"></span> </div>
                        </a>
                        <div class=\"dropdown-menu dropdown-menu-right mailbox animated zoomIn\">
                            <ul>
                                <li>
                                    <div class=\"drop-title\">Notifications</div>
                                </li>
                                <li>
                                    <div class=\"message-center\">
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"btn btn-danger btn-circle m-r-10\"><i class=\"fa fa-link\"></i></div>
                                            <div class=\"mail-contnet\">
                                                <h5>This is title</h5> <span class=\"mail-desc\">Just see the my new admin!</span> <span class=\"time\">9:30 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"btn btn-success btn-circle m-r-10\"><i class=\"ti-calendar\"></i></div>
                                            <div class=\"mail-contnet\">
                                                <h5>This is another title</h5> <span class=\"mail-desc\">Just a reminder that you have event</span> <span class=\"time\">9:10 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"btn btn-info btn-circle m-r-10\"><i class=\"ti-settings\"></i></div>
                                            <div class=\"mail-contnet\">
                                                <h5>This is title</h5> <span class=\"mail-desc\">You can customize this template as you want</span> <span class=\"time\">9:08 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"btn btn-primary btn-circle m-r-10\"><i class=\"ti-user\"></i></div>
                                            <div class=\"mail-contnet\">
                                                <h5>This is another title</h5> <span class=\"mail-desc\">Just see the my admin!</span> <span class=\"time\">9:02 AM</span>
                                            </div>
                                        </a>
                                    </div>
                                </li>
                                <li>
                                    <a class=\"nav-link text-center\" href=\"javascript:void(0);\"> <strong>Check all notifications</strong> <i class=\"fa fa-angle-right\"></i> </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <!-- End Comment -->
                    <!-- Messages -->
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle text-muted  \" href=\"#\" id=\"2\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"> <i class=\"fa fa-envelope\"></i>
                            <div class=\"notify\"> <span class=\"heartbit\"></span> <span class=\"point\"></span> </div>
                        </a>
                        <div class=\"dropdown-menu dropdown-menu-right mailbox animated zoomIn\" aria-labelledby=\"2\">
                            <ul>
                                <li>
                                    <div class=\"drop-title\">You have 4 new messages</div>
                                </li>
                                <li>
                                    <div class=\"message-center\">
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"user-img\"> <img src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/users/5.jpg"), "html", null, true);
        echo "\" alt=\"user\" class=\"img-circle\"> <span class=\"profile-status online pull-right\"></span> </div>
                                            <div class=\"mail-contnet\">
                                                <h5>Michael Qin</h5> <span class=\"mail-desc\">Just see the my admin!</span> <span class=\"time\">9:30 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"user-img\"> <img src=\"";
        // line 150
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/users/2.jpg"), "html", null, true);
        echo "\" alt=\"user\" class=\"img-circle\"> <span class=\"profile-status busy pull-right\"></span> </div>
                                            <div class=\"mail-contnet\">
                                                <h5>John Doe</h5> <span class=\"mail-desc\">I've sung a song! See you at</span> <span class=\"time\">9:10 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"user-img\"> <img src=\"";
        // line 157
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/users/3.jpg"), "html", null, true);
        echo "\" alt=\"user\" class=\"img-circle\"> <span class=\"profile-status away pull-right\"></span> </div>
                                            <div class=\"mail-contnet\">
                                                <h5>Mr. John</h5> <span class=\"mail-desc\">I am a singer!</span> <span class=\"time\">9:08 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"user-img\"> <img src=\"";
        // line 164
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/users/4.jpg"), "html", null, true);
        echo "\" alt=\"user\" class=\"img-circle\"> <span class=\"profile-status offline pull-right\"></span> </div>
                                            <div class=\"mail-contnet\">
                                                <h5>Michael Qin</h5> <span class=\"mail-desc\">Just see the my admin!</span> <span class=\"time\">9:02 AM</span>
                                            </div>
                                        </a>
                                    </div>
                                </li>
                                <li>
                                    <a class=\"nav-link text-center\" href=\"javascript:void(0);\"> <strong>See all e-Mails</strong> <i class=\"fa fa-angle-right\"></i> </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <!-- End Messages -->
                    <li style=\"
    height: 30px;
    padding-top: 20px;
    padding-left: 10px;
    padding-right: 10px;
\">
                        ";
        // line 184
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo "
                    </li>
                    <!-- Profile -->
                    <li class=\"nav-item dropdown\">

                        <a class=\"nav-link dropdown-toggle text-muted  \" href=\"#\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"><img src=\"";
        // line 189
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/users/5.jpg"), "html", null, true);
        echo "\" alt=\"user\" class=\"profile-pic\" /></a>
                        <div class=\"dropdown-menu dropdown-menu-right animated zoomIn\">
                            <ul class=\"dropdown-user\">
                                <li><a href=\"#\"><i class=\"ti-user\"></i> Profile</a></li>
                                <li><a href=\"#\"><i class=\"ti-wallet\"></i> Balance</a></li>
                                <li><a href=\"#\"><i class=\"ti-email\"></i> Inbox</a></li>
                                <li><a href=\"#\"><i class=\"ti-settings\"></i> Setting</a></li>
                                <li><a href=\"";
        // line 196
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
        echo "\"><i class=\"fa fa-power-off\"></i> Logout</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <!-- End header header -->
    <!-- Left Sidebar  -->



    <div class=\"left-sidebar\">
        <!-- Sidebar scroll-->
        <div class=\"scroll-sidebar\">
            <!-- Sidebar navigation-->
            <nav class=\"sidebar-nav\">
                <ul id=\"sidebarnav\">
                    <li class=\"nav-devider\"></li>
                    <li class=\"nav-label\">Home</li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-tachometer\"></i><span class=\"hide-menu\">Dashboard <span class=\"label label-rouded label-primary pull-right\">2</span></span></a>

                    </li>
                    <li class=\"nav-label\">Parametre</li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-edit\"></i><span class=\"hide-menu\">Generale</span></a>
                    <li class=\"nav-label\">Services</li>
                    </li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-suitcase\"></i><span class=\"hide-menu\">Stage</span></a>

                    </li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-globe\"></i><span class=\"hide-menu\">Commodité</span></a>

                    </li>

                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-home\"></i><span class=\"hide-menu\">Logement <span class=\"label label-rouded label-warning pull-right\">6</span></span></a>

                    </li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-automobile\"></i><span class=\"hide-menu\">Transport <span class=\"label label-rouded label-danger pull-right\">6</span></span></a>

                    </li>
                    <li class=\"nav-label\">Club&Event</li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\">
                            <i class=\"fa fa-wpforms\"></i>
                            <span class=\"hide-menu\">Clubs</span>
                        </a>
                        <ul aria-expanded=\"false\" class=\"collapse\">
                            <li><a href=\"";
        // line 243
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("list_club");
        echo "\">list des clubs </a></li>
                            <li><a href=\"";
        // line 244
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_club");
        echo "\">Ajout club </a></li>
                        </ul>

                    </li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\">
                            <i class=\"fa fa-table\"></i>
                            <span class=\"hide-menu\">Events</span>
                        </a>
                        <ul aria-expanded=\"false\" class=\"collapse\">
                            <li><a href=\"";
        // line 253
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("list_event");
        echo "\">list des evenements </a></li>
                            <li><a href=\"";
        // line 254
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_event");
        echo "\">Ajout Evenement </a></li>
                        </ul>

                    </li>

                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-columns\"></i><span class=\"hide-menu\">Orientation</span></a>

                    </li>


                </ul>
            </nav>
            <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
    </div>

    <!-- End Left Sidebar  -->
    <!-- Page wrapper  -->
    ";
        // line 273
        $this->displayBlock('content', $context, $blocks);
        // line 280
        echo "





    <!-- End Page wrapper  -->
</div>
<!-- End Wrapper -->
<!-- All Jquery -->

<!--Custom JavaScript -->


<!-- Amchart -->

";
        // line 296
        $this->displayBlock('javascripts', $context, $blocks);
        // line 329
        echo "</body>

</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "        <title>welcome</title>
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 12
        echo "        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <!-- Tell the browser to be responsive to screen width -->
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <meta name=\"description\" content=\"\">
        <meta name=\"author\" content=\"\">
        <!-- Favicon icon -->
        <link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\">

        <!-- Bootstrap Core CSS -->
        <link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/lib/bootstrap/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <!-- Custom CSS -->

        <link href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/css/lib/calendar2/semantic.ui.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/css/lib/calendar2/pignose.calendar.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/css/lib/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
        <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/css/lib/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
        <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/css/helper.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 273
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 274
        echo "

        ";
        // line 276
        $this->displayBlock('footer', $context, $blocks);
        // line 279
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 276
    public function block_footer($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 277
        echo "
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 296
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 297
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src=\"";
        // line 299
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/bootstrap/js/popper.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 300
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src=\"";
        // line 302
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/jquery.slimscroll.js"), "html", null, true);
        echo "\"></script>
    <!--Menu sidebar -->
    <script src=\"";
        // line 304
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/sidebarmenu.js"), "html", null, true);
        echo "\"></script>
    <!--stickey kit -->
    <script src=\"";
        // line 306
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/sticky-kit-master/dist/sticky-kit.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 307
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/morris-chart/raphael-min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 308
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/morris-chart/morris.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 309
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/morris-chart/dashboard1-init.js"), "html", null, true);
        echo "\"></script>


    <script src=\"";
        // line 312
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/calendar-2/moment.latest.min.js"), "html", null, true);
        echo "\"></script>
    <!-- scripit init-->
    <script src=\"";
        // line 314
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/calendar-2/semantic.ui.min.js"), "html", null, true);
        echo "\"></script>
    <!-- scripit init-->
    <script src=\"";
        // line 316
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/calendar-2/prism.min.js"), "html", null, true);
        echo "\"></script>
    <!-- scripit init-->
    <script src=\"";
        // line 318
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/calendar-2/pignose.calendar.min.js"), "html", null, true);
        echo "\"></script>
    <!-- scripit init-->
    <script src=\"";
        // line 320
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/calendar-2/pignose.init.js"), "html", null, true);
        echo "\"></script>

    <script src=\"";
        // line 322
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/owl-carousel/owl.carousel.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 323
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/lib/owl-carousel/owl.carousel-init.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 324
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/scripts.js"), "html", null, true);
        echo "\"></script>
    <!-- scripit init-->

    <script src=\"";
        // line 327
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("admin/js/custom.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "EspritEntraideBundle::layoutadmin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  579 => 327,  573 => 324,  569 => 323,  565 => 322,  560 => 320,  555 => 318,  550 => 316,  545 => 314,  540 => 312,  534 => 309,  530 => 308,  526 => 307,  522 => 306,  517 => 304,  512 => 302,  507 => 300,  503 => 299,  497 => 297,  488 => 296,  477 => 277,  468 => 276,  458 => 279,  456 => 276,  452 => 274,  443 => 273,  430 => 30,  426 => 29,  422 => 28,  418 => 27,  414 => 26,  410 => 25,  404 => 22,  398 => 19,  389 => 12,  380 => 11,  369 => 7,  360 => 6,  348 => 329,  346 => 296,  328 => 280,  326 => 273,  304 => 254,  300 => 253,  288 => 244,  284 => 243,  234 => 196,  224 => 189,  216 => 184,  193 => 164,  183 => 157,  173 => 150,  163 => 143,  75 => 58,  69 => 55,  45 => 33,  43 => 11,  39 => 9,  37 => 6,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">

<head>

    {% block title %}
        <title>welcome</title>
    {% endblock %}


    {% block stylesheets %}
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <!-- Tell the browser to be responsive to screen width -->
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <meta name=\"description\" content=\"\">
        <meta name=\"author\" content=\"\">
        <!-- Favicon icon -->
        <link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"{{ asset ('images/favicon.png')}}\">

        <!-- Bootstrap Core CSS -->
        <link href=\"{{ asset ('css/lib/bootstrap/bootstrap.min.css')}}\" rel=\"stylesheet\">
        <!-- Custom CSS -->

        <link href=\"{{ asset ('admin/css/lib/calendar2/semantic.ui.min.css')}}\" rel=\"stylesheet\">
        <link href=\"{{ asset ('admin/css/lib/calendar2/pignose.calendar.min.css')}}\" rel=\"stylesheet\">
        <link href=\"{{ asset ('admin/css/lib/owl.carousel.min.css')}}\" rel=\"stylesheet\" />
        <link href=\"{{ asset ('admin/css/lib/owl.theme.default.min.css')}}\" rel=\"stylesheet\" />
        <link href=\"{{ asset ('admin/css/helper.css')}}\" rel=\"stylesheet\">
        <link href=\"{{ asset ('admin/css/style.css')}}\" rel=\"stylesheet\">

    {% endblock %}




    <![endif]-->
</head>

<body class=\"fix-header fix-sidebar\">
<!-- Preloader - style you can find in spinners.css -->
<div class=\"preloader\">
    <svg class=\"circular\" viewBox=\"25 25 50 50\">
        <circle class=\"path\" cx=\"50\" cy=\"50\" r=\"20\" fill=\"none\" stroke-width=\"2\" stroke-miterlimit=\"10\" /> </svg>
</div>
<!-- Main wrapper  -->
<div id=\"main-wrapper\">
    <!-- header header  -->
    <div class=\"header\">
        <nav class=\"navbar top-navbar navbar-expand-md navbar-light\">
            <!-- Logo -->
            <div class=\"navbar-header\">
                <a class=\"navbar-brand\" href=\"index.html\">
                    <!-- Logo icon -->
                    <b><img src=\"{{ asset ('images/logo.png')}}\" alt=\"homepage\" class=\"dark-logo\" /></b>
                    <!--End Logo icon -->
                    <!-- Logo text -->
                    <span><img src=\"{{ asset ('images/logo-text.png')}}\" alt=\"homepage\" class=\"dark-logo\" /></span>
                </a>
            </div>
            <!-- End Logo -->
            <div class=\"navbar-collapse\">
                <!-- toggle and nav items -->
                <ul class=\"navbar-nav mr-auto mt-md-0\">
                    <!-- This is  -->
                    <li class=\"nav-item\"> <a class=\"nav-link nav-toggler hidden-md-up text-muted  \" href=\"javascript:void(0)\"><i class=\"mdi mdi-menu\"></i></a> </li>
                    <li class=\"nav-item m-l-10\"> <a class=\"nav-link sidebartoggler hidden-sm-down text-muted  \" href=\"javascript:void(0)\"><i class=\"ti-menu\"></i></a> </li>
                    <!-- Messages -->

                    <!-- End Messages -->
                </ul>
                <!-- User profile and search -->
                <ul class=\"navbar-nav my-lg-0\">

                    <!-- Search -->
                    <li class=\"nav-item hidden-sm-down search-box\"> <a class=\"nav-link hidden-sm-down text-muted  \" href=\"javascript:void(0)\"><i class=\"ti-search\"></i></a>
                        <form class=\"app-search\">
                            <input type=\"text\" class=\"form-control\" placeholder=\"Search here\"> <a class=\"srh-btn\"><i class=\"ti-close\"></i></a> </form>
                    </li>
                    <!-- Comment -->
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle text-muted text-muted  \" href=\"#\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"> <i class=\"fa fa-bell\"></i>
                            <div class=\"notify\"> <span class=\"heartbit\"></span> <span class=\"point\"></span> </div>
                        </a>
                        <div class=\"dropdown-menu dropdown-menu-right mailbox animated zoomIn\">
                            <ul>
                                <li>
                                    <div class=\"drop-title\">Notifications</div>
                                </li>
                                <li>
                                    <div class=\"message-center\">
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"btn btn-danger btn-circle m-r-10\"><i class=\"fa fa-link\"></i></div>
                                            <div class=\"mail-contnet\">
                                                <h5>This is title</h5> <span class=\"mail-desc\">Just see the my new admin!</span> <span class=\"time\">9:30 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"btn btn-success btn-circle m-r-10\"><i class=\"ti-calendar\"></i></div>
                                            <div class=\"mail-contnet\">
                                                <h5>This is another title</h5> <span class=\"mail-desc\">Just a reminder that you have event</span> <span class=\"time\">9:10 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"btn btn-info btn-circle m-r-10\"><i class=\"ti-settings\"></i></div>
                                            <div class=\"mail-contnet\">
                                                <h5>This is title</h5> <span class=\"mail-desc\">You can customize this template as you want</span> <span class=\"time\">9:08 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"btn btn-primary btn-circle m-r-10\"><i class=\"ti-user\"></i></div>
                                            <div class=\"mail-contnet\">
                                                <h5>This is another title</h5> <span class=\"mail-desc\">Just see the my admin!</span> <span class=\"time\">9:02 AM</span>
                                            </div>
                                        </a>
                                    </div>
                                </li>
                                <li>
                                    <a class=\"nav-link text-center\" href=\"javascript:void(0);\"> <strong>Check all notifications</strong> <i class=\"fa fa-angle-right\"></i> </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <!-- End Comment -->
                    <!-- Messages -->
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle text-muted  \" href=\"#\" id=\"2\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"> <i class=\"fa fa-envelope\"></i>
                            <div class=\"notify\"> <span class=\"heartbit\"></span> <span class=\"point\"></span> </div>
                        </a>
                        <div class=\"dropdown-menu dropdown-menu-right mailbox animated zoomIn\" aria-labelledby=\"2\">
                            <ul>
                                <li>
                                    <div class=\"drop-title\">You have 4 new messages</div>
                                </li>
                                <li>
                                    <div class=\"message-center\">
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"user-img\"> <img src=\"{{ asset('images/users/5.jpg')}}\" alt=\"user\" class=\"img-circle\"> <span class=\"profile-status online pull-right\"></span> </div>
                                            <div class=\"mail-contnet\">
                                                <h5>Michael Qin</h5> <span class=\"mail-desc\">Just see the my admin!</span> <span class=\"time\">9:30 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"user-img\"> <img src=\"{{ asset('images/users/2.jpg')}}\" alt=\"user\" class=\"img-circle\"> <span class=\"profile-status busy pull-right\"></span> </div>
                                            <div class=\"mail-contnet\">
                                                <h5>John Doe</h5> <span class=\"mail-desc\">I've sung a song! See you at</span> <span class=\"time\">9:10 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"user-img\"> <img src=\"{{ asset('images/users/3.jpg')}}\" alt=\"user\" class=\"img-circle\"> <span class=\"profile-status away pull-right\"></span> </div>
                                            <div class=\"mail-contnet\">
                                                <h5>Mr. John</h5> <span class=\"mail-desc\">I am a singer!</span> <span class=\"time\">9:08 AM</span>
                                            </div>
                                        </a>
                                        <!-- Message -->
                                        <a href=\"#\">
                                            <div class=\"user-img\"> <img src=\"{{ asset('images/users/4.jpg')}}\" alt=\"user\" class=\"img-circle\"> <span class=\"profile-status offline pull-right\"></span> </div>
                                            <div class=\"mail-contnet\">
                                                <h5>Michael Qin</h5> <span class=\"mail-desc\">Just see the my admin!</span> <span class=\"time\">9:02 AM</span>
                                            </div>
                                        </a>
                                    </div>
                                </li>
                                <li>
                                    <a class=\"nav-link text-center\" href=\"javascript:void(0);\"> <strong>See all e-Mails</strong> <i class=\"fa fa-angle-right\"></i> </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <!-- End Messages -->
                    <li style=\"
    height: 30px;
    padding-top: 20px;
    padding-left: 10px;
    padding-right: 10px;
\">
                        {{ app.user.username }}
                    </li>
                    <!-- Profile -->
                    <li class=\"nav-item dropdown\">

                        <a class=\"nav-link dropdown-toggle text-muted  \" href=\"#\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"><img src=\"{{ asset('images/users/5.jpg')}}\" alt=\"user\" class=\"profile-pic\" /></a>
                        <div class=\"dropdown-menu dropdown-menu-right animated zoomIn\">
                            <ul class=\"dropdown-user\">
                                <li><a href=\"#\"><i class=\"ti-user\"></i> Profile</a></li>
                                <li><a href=\"#\"><i class=\"ti-wallet\"></i> Balance</a></li>
                                <li><a href=\"#\"><i class=\"ti-email\"></i> Inbox</a></li>
                                <li><a href=\"#\"><i class=\"ti-settings\"></i> Setting</a></li>
                                <li><a href=\"{{ path('fos_user_security_logout') }}\"><i class=\"fa fa-power-off\"></i> Logout</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <!-- End header header -->
    <!-- Left Sidebar  -->



    <div class=\"left-sidebar\">
        <!-- Sidebar scroll-->
        <div class=\"scroll-sidebar\">
            <!-- Sidebar navigation-->
            <nav class=\"sidebar-nav\">
                <ul id=\"sidebarnav\">
                    <li class=\"nav-devider\"></li>
                    <li class=\"nav-label\">Home</li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-tachometer\"></i><span class=\"hide-menu\">Dashboard <span class=\"label label-rouded label-primary pull-right\">2</span></span></a>

                    </li>
                    <li class=\"nav-label\">Parametre</li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-edit\"></i><span class=\"hide-menu\">Generale</span></a>
                    <li class=\"nav-label\">Services</li>
                    </li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-suitcase\"></i><span class=\"hide-menu\">Stage</span></a>

                    </li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-globe\"></i><span class=\"hide-menu\">Commodité</span></a>

                    </li>

                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-home\"></i><span class=\"hide-menu\">Logement <span class=\"label label-rouded label-warning pull-right\">6</span></span></a>

                    </li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-automobile\"></i><span class=\"hide-menu\">Transport <span class=\"label label-rouded label-danger pull-right\">6</span></span></a>

                    </li>
                    <li class=\"nav-label\">Club&Event</li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\">
                            <i class=\"fa fa-wpforms\"></i>
                            <span class=\"hide-menu\">Clubs</span>
                        </a>
                        <ul aria-expanded=\"false\" class=\"collapse\">
                            <li><a href=\"{{ path('list_club') }}\">list des clubs </a></li>
                            <li><a href=\"{{ path('add_club') }}\">Ajout club </a></li>
                        </ul>

                    </li>
                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\">
                            <i class=\"fa fa-table\"></i>
                            <span class=\"hide-menu\">Events</span>
                        </a>
                        <ul aria-expanded=\"false\" class=\"collapse\">
                            <li><a href=\"{{ path('list_event') }}\">list des evenements </a></li>
                            <li><a href=\"{{ path('add_event') }}\">Ajout Evenement </a></li>
                        </ul>

                    </li>

                    <li> <a class=\"has-arrow  \" href=\"#\" aria-expanded=\"false\"><i class=\"fa fa-columns\"></i><span class=\"hide-menu\">Orientation</span></a>

                    </li>


                </ul>
            </nav>
            <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
    </div>

    <!-- End Left Sidebar  -->
    <!-- Page wrapper  -->
    {% block content %}


        {% block footer %}

        {% endblock %}
    {% endblock %}






    <!-- End Page wrapper  -->
</div>
<!-- End Wrapper -->
<!-- All Jquery -->

<!--Custom JavaScript -->


<!-- Amchart -->

{% block javascripts %}
    <script src=\"{{ asset ('admin/js/lib/jquery/jquery.min.js')}}\"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src=\"{{ asset ('admin/js/lib/bootstrap/js/popper.min.js')}}\"></script>
    <script src=\"{{ asset ('admin/js/lib/bootstrap/js/bootstrap.min.js')}}\"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src=\"{{ asset ('admin/js/jquery.slimscroll.js')}}\"></script>
    <!--Menu sidebar -->
    <script src=\"{{ asset ('admin/js/sidebarmenu.js')}}\"></script>
    <!--stickey kit -->
    <script src=\"{{ asset ('admin/js/lib/sticky-kit-master/dist/sticky-kit.min.js')}}\"></script>
    <script src=\"{{ asset ('admin/js/lib/morris-chart/raphael-min.js')}}\"></script>
    <script src=\"{{ asset ('admin/js/lib/morris-chart/morris.js')}}\"></script>
    <script src=\"{{ asset ('admin/js/lib/morris-chart/dashboard1-init.js')}}\"></script>


    <script src=\"{{ asset ('admin/js/lib/calendar-2/moment.latest.min.js')}}\"></script>
    <!-- scripit init-->
    <script src=\"{{ asset ('admin/js/lib/calendar-2/semantic.ui.min.js')}}\"></script>
    <!-- scripit init-->
    <script src=\"{{ asset ('admin/js/lib/calendar-2/prism.min.js')}}\"></script>
    <!-- scripit init-->
    <script src=\"{{ asset ('admin/js/lib/calendar-2/pignose.calendar.min.js')}}\"></script>
    <!-- scripit init-->
    <script src=\"{{ asset ('admin/js/lib/calendar-2/pignose.init.js')}}\"></script>

    <script src=\"{{ asset ('admin/js/lib/owl-carousel/owl.carousel.min.js')}}\"></script>
    <script src=\"{{ asset ('admin/js/lib/owl-carousel/owl.carousel-init.js')}}\"></script>
    <script src=\"{{ asset ('admin/js/scripts.js')}}\"></script>
    <!-- scripit init-->

    <script src=\"{{ asset ('admin/js/custom.min.js')}}\"></script>
{% endblock %}
</body>

</html>", "EspritEntraideBundle::layoutadmin.html.twig", "C:\\wamp64\\www\\EspritEntraide\\src\\EspritEntraideBundle\\Resources\\views\\layoutadmin.html.twig");
    }
}
