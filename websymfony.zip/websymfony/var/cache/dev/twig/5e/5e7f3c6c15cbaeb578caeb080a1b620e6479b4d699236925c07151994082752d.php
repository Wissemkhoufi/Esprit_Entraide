<?php

/* EspritEntraideBundle::layout.html.twig */
class __TwigTemplate_12dd53ebebe2dc0deba29892cbf301fa12e99be95f67e708c5d386beea9bc7c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'entree' => array($this, 'block_entree'),
            'containt' => array($this, 'block_containt'),
            'javascripts' => array($this, 'block_javascripts'),
            'javascripts2' => array($this, 'block_javascripts2'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle::layout.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EspritEntraideBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "    ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 45
        echo "

</head>
<body>
<!-- Pre Loader -->
<div id=\"loader\"></div>
<!--Header-->
<header id=\"home\">
    <div class=\"header-top-area\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-3\">
                    <!-- START LOGO -->
                    <div class=\"logo\"><a href=\"";
        // line 58
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("esprit_entraide_homepage");
        echo "\">SWAT</a></div>
                    <!-- END LOGO -->
                    <div class=\"mobile-nav\"></div>
                </div>
                <div class=\"col-md-9\">
                    <!-- START MAIN MENU -->
                    <nav class=\"navbar navbar-default\">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class=\"navbar-header\"></div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class=\"collapse navbar-collapse\">
                            <div class=\"navigation\">
                                <ul class=\"nav navbar-nav\">
                                    <li><a href=\"#home\">Evenement</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"";
        // line 73
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_user_event");
        echo "\">Ajout evenement</a></li>
                                            <li><a href=\"";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("list_user_event");
        echo "\">Liste des evenements</a></li>
                                            <li><a href=\"";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("mylist_user_event");
        echo "\">Mes evenements</a></li>
                                            <li><a href=\"";
        // line 76
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_search_event");
        echo "\">recherche evenements</a></li>
                                        </ul>
                                    </li>
                                    <li><a href=\"#\">Clubs</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_user_club");
        echo "\">Add Club</a></li>
                                            <li><a href=\"";
        // line 82
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("list_user_club");
        echo "\">Liste des clubs</a></li>
                                            <li><a href=\"";
        // line 83
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("mylist_user_club");
        echo "\">Mes clubs</a></li>
                                            <li><a href=\"";
        // line 84
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show_search_club");
        echo "\">recherche clubs</a></li>

                                        </ul>
                                    </li>

                                    <li><a href=\"#\">Shortcodes</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"accordion.html\">Accordion</a></li>
                                            <li><a href=\"tab.html\">Tab</a></li>
                                            <li><a href=\"button.html\">Button</a></li>
                                            <li><a href=\"counter.html\">Counter</a></li>
                                            <li><a href=\"team.html\">Team</a></li>
                                            <li><a href=\"features.html\">Features</a></li>
                                            <li><a href=\"client.html\">Client</a></li>
                                        </ul>
                                    </li>
                                    <li><a href=\"#\">Portfolio</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"portfolio-one.html\">Portfolio-one</a></li>
                                            <li><a href=\"portfolio-two.html\">Portfolio-two</a></li>
                                            <li><a href=\"portfolio-three.html\">Portfolio-three</a></li>
                                            <li><a href=\"portfolio-four.html\">Portfolio-four</a></li>
                                        </ul>
                                    </li>
                                    <li><a href=\"#\">Blogs</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"blog-single.html\">Blog-single</a></li>
                                            <li><a href=\"blog-grid.html\">Blog-grid</a></li>
                                            <li><a href=\"blog-classic.html\">Blog-classic</a></li>
                                        </ul>
                                    </li>
                                    <li><a href=\"contact-us.html\">Contact Us</a></li>

                                    <li><a href=\"";
        // line 117
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
        echo "\">Logout</a></li>

                                </ul>
                            </div>
                        </div>
                        <!-- /.navbar-collapse -->
                    </nav>
                    <!-- END MAIN MENU -->
                </div>
            </div>
        </div>
    </div>
    <!-- Start Particle area -->

    ";
        // line 131
        $this->displayBlock('entree', $context, $blocks);
        // line 134
        echo "    <!-- End Particle area -->
</header>

<div class=\"container\" style=\"margin-top: 56px;padding: 50px 0;\">
    ";
        // line 138
        $this->displayBlock('containt', $context, $blocks);
        // line 141
        echo "</div>



<section id=\"footer\" class=\"footer\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-3\">
                <div class=\"logo pt-0\"><a href=\"index.html\">SWAT</a></div>
                <p class=\"font-w-6 pt-20 font-15 ln-h-30\"><span class=\"Color-b\">SWAT</span> is a fully responsive
                    Multipurpose Bootstrap 3 Template built for web-designers, web-developers, business and any
                    other creative people to build Bootstrap based websites.</p>
            </div>
            <div class=\"col-md-3\">
                <div class=\"section-title-2\">
                    <h3>UseFull Links</h3>
                </div>
                <div class=\"sidebar-post pt-15\">
                    <ul>
                        <li><a href=\"#\">Home Page Variations</a></li>
                        <li><a href=\"#\">Features Typography</a></li>
                        <li><a href=\"#\">Recent Blogs or News</a></li>
                        <li><a href=\"#\">Single and Portfolios</a></li>
                        <li><a href=\"#\">Company History</a></li>
                        <li><a href=\"#\">Different & Unique Pages</a></li>
                    </ul>
                </div>
            </div>
            <div class=\"col-md-3\">
                <div class=\"section-title-2\">
                    <h3>Photo Gallery</h3>
                </div>
                <div class=\"sidebar-gallery\">

                </div>
            </div>
            <div class=\"col-md-3\">
                <div class=\"section-title-2\">
                    <h3>Newsletter</h3>
                </div>
                <div class=\"footer-address\">
                    <p class=\"font-w-6\">Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry.</p>
                    <p class=\"font-w-6\"><span class=\"Color-b\">Street :</span> Orlando, Florida, USA</p>
                    <p class=\"font-w-6\"><span class=\"Color-b\">Email :</span> email@example.com</p>
                    <p class=\"font-w-6\"><span class=\"Color-b\">Phone :</span> +880123456789</p>
                </div>
                <div class=\"footer-social pt-15\">
                    <ul class=\"top-social\">
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-facebook\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-twitter\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-pinterest\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-dribbble\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-linkedin\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-rss\"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Contact end-->
<footer>
    <div class=\"clearfix\"></div>
    <div class=\"container\">
        <p class=\"text-center pt-10\">&copy; Copyright
            <script>
                var d = new Date();
                document.write(d.getFullYear());
            </script>
            SWAT | All Rights Reserved.
        </p>
    </div>
</footer>

";
        // line 216
        $this->displayBlock('javascripts', $context, $blocks);
        // line 238
        echo "
";
        // line 239
        $this->displayBlock('javascripts2', $context, $blocks);
        // line 244
        echo "</body>
</html>

";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <!-- Bootstrap Css -->
        <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

        <!-- Normalize Css -->
        <link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/Normalize/normalize.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <!--Font Awesome Css-->
        <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <!--Linear icon Css-->
        <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/linearicons/css/icon-font.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <!--Animate Css-->
        <link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/animate/animate.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <!--Owl carousel css-->
        <link href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/owlcarousel/css/owl.carousel.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/owlcarousel/css/owl.theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <!--Portfolio Css-->
        <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/css/ionicons.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/css/magnific-popup.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <!--Slicknav Css-->
        <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/slicknav/slicknav.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">


        <!--Custum Css-->
        <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <!--Responsive Css-->
        <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/css/responsive.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/starrating/css/rating.css"), "html", null, true);
        echo "\" />
        <!--Modernizr Js-->
        <script src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/js/vendor/modernizr-3.5.0.min.js"), "html", null, true);
        echo "\"></script>
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
        <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>-->
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 131
    public function block_entree($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "entree"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "entree"));

        // line 132
        echo "
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 138
    public function block_containt($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "containt"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "containt"));

        // line 139
        echo "
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 216
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 217
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/jquery/jquery-3.2.1.min.js"), "html", null, true);
        echo "\"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src=\"";
        // line 219
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 220
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/easing/jquery.easing.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 221
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/isotope/jquery.isotope.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 222
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/jquery/imagesloaded.pkgd.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 223
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/wow/wow.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/slicknav/jquery.slicknav.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 225
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/particle/particles.min.js"), "html", null, true);
        echo "\"></script>

    <script src=\"";
        // line 227
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/owlcarousel/js/owl.carousel.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 228
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/jquery/jquery.magnific-popup.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 229
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/number-animation/jquery.animateNumber.min.js"), "html", null, true);
        echo "\"></script>
    <!-- Contact Form Script -->
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js\"></script>
    <script src=\"";
        // line 232
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/contact-form/js/validator.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 233
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/contact-form/js/form-scripts.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 234
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/jquery/plugins.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 235
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/js/custom.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 239
    public function block_javascripts2($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts2"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts2"));

        // line 240
        echo "
    <script src=\"";
        // line 241
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("user/assets/particle/app.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "EspritEntraideBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  518 => 241,  515 => 240,  506 => 239,  493 => 235,  489 => 234,  485 => 233,  481 => 232,  475 => 229,  471 => 228,  467 => 227,  462 => 225,  458 => 224,  454 => 223,  450 => 222,  446 => 221,  442 => 220,  438 => 219,  432 => 217,  423 => 216,  412 => 139,  403 => 138,  392 => 132,  383 => 131,  366 => 38,  361 => 36,  357 => 35,  352 => 33,  345 => 29,  340 => 27,  336 => 26,  331 => 24,  327 => 23,  322 => 21,  317 => 19,  312 => 17,  307 => 15,  301 => 12,  295 => 8,  286 => 7,  268 => 6,  255 => 244,  253 => 239,  250 => 238,  248 => 216,  171 => 141,  169 => 138,  163 => 134,  161 => 131,  144 => 117,  108 => 84,  104 => 83,  100 => 82,  96 => 81,  88 => 76,  84 => 75,  80 => 74,  76 => 73,  58 => 58,  43 => 45,  40 => 7,  38 => 6,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    {% block title %} {% endblock %}
    {% block stylesheets %}
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <!-- Bootstrap Css -->
        <link href=\"{{ asset ('user/assets/bootstrap/css/bootstrap.min.css') }}\" rel=\"stylesheet\">

        <!-- Normalize Css -->
        <link href=\"{{ asset ('user/assets/Normalize/normalize.css') }}\" rel=\"stylesheet\">
        <!--Font Awesome Css-->
        <link href=\"{{ asset ('user/assets/font-awesome/css/font-awesome.min.css') }}\" rel=\"stylesheet\">
        <!--Linear icon Css-->
        <link href=\"{{ asset ('user/assets/linearicons/css/icon-font.min.css') }}\" rel=\"stylesheet\">
        <!--Animate Css-->
        <link href=\"{{ asset ('user/assets/animate/animate.css') }}\" rel=\"stylesheet\">
        <!--Owl carousel css-->
        <link href=\"{{ asset ('user/assets/owlcarousel/css/owl.carousel.css') }}\" rel=\"stylesheet\">
        <link href=\"{{ asset ('user/assets/owlcarousel/css/owl.theme.css') }}\" rel=\"stylesheet\">
        <!--Portfolio Css-->
        <link href=\"{{ asset ('user/assets/css/ionicons.min.css') }}\" rel=\"stylesheet\">
        <link href=\"{{ asset ('user/assets/css/magnific-popup.css') }}\" rel=\"stylesheet\">
        <!--Slicknav Css-->
        <link href=\"{{ asset ('user/assets/slicknav/slicknav.css') }}\" rel=\"stylesheet\">


        <!--Custum Css-->
        <link href=\"{{ asset ('user/css/style.css') }}\" rel=\"stylesheet\">
        <!--Responsive Css-->
        <link href=\"{{ asset ('user/css/responsive.css') }}\" rel=\"stylesheet\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('bundles/starrating/css/rating.css') }}\" />
        <!--Modernizr Js-->
        <script src=\"{{ asset ('user/js/vendor/modernizr-3.5.0.min.js') }}\"></script>
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
        <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>-->
    {% endblock %}


</head>
<body>
<!-- Pre Loader -->
<div id=\"loader\"></div>
<!--Header-->
<header id=\"home\">
    <div class=\"header-top-area\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-3\">
                    <!-- START LOGO -->
                    <div class=\"logo\"><a href=\"{{ path('esprit_entraide_homepage') }}\">SWAT</a></div>
                    <!-- END LOGO -->
                    <div class=\"mobile-nav\"></div>
                </div>
                <div class=\"col-md-9\">
                    <!-- START MAIN MENU -->
                    <nav class=\"navbar navbar-default\">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class=\"navbar-header\"></div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class=\"collapse navbar-collapse\">
                            <div class=\"navigation\">
                                <ul class=\"nav navbar-nav\">
                                    <li><a href=\"#home\">Evenement</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"{{ path('add_user_event') }}\">Ajout evenement</a></li>
                                            <li><a href=\"{{ path('list_user_event') }}\">Liste des evenements</a></li>
                                            <li><a href=\"{{ path('mylist_user_event') }}\">Mes evenements</a></li>
                                            <li><a href=\"{{ path('show_search_event') }}\">recherche evenements</a></li>
                                        </ul>
                                    </li>
                                    <li><a href=\"#\">Clubs</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"{{ path('add_user_club') }}\">Add Club</a></li>
                                            <li><a href=\"{{ path('list_user_club') }}\">Liste des clubs</a></li>
                                            <li><a href=\"{{ path('mylist_user_club') }}\">Mes clubs</a></li>
                                            <li><a href=\"{{ path('show_search_club') }}\">recherche clubs</a></li>

                                        </ul>
                                    </li>

                                    <li><a href=\"#\">Shortcodes</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"accordion.html\">Accordion</a></li>
                                            <li><a href=\"tab.html\">Tab</a></li>
                                            <li><a href=\"button.html\">Button</a></li>
                                            <li><a href=\"counter.html\">Counter</a></li>
                                            <li><a href=\"team.html\">Team</a></li>
                                            <li><a href=\"features.html\">Features</a></li>
                                            <li><a href=\"client.html\">Client</a></li>
                                        </ul>
                                    </li>
                                    <li><a href=\"#\">Portfolio</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"portfolio-one.html\">Portfolio-one</a></li>
                                            <li><a href=\"portfolio-two.html\">Portfolio-two</a></li>
                                            <li><a href=\"portfolio-three.html\">Portfolio-three</a></li>
                                            <li><a href=\"portfolio-four.html\">Portfolio-four</a></li>
                                        </ul>
                                    </li>
                                    <li><a href=\"#\">Blogs</a>
                                        <ul class=\"drop-down\">
                                            <li><a href=\"blog-single.html\">Blog-single</a></li>
                                            <li><a href=\"blog-grid.html\">Blog-grid</a></li>
                                            <li><a href=\"blog-classic.html\">Blog-classic</a></li>
                                        </ul>
                                    </li>
                                    <li><a href=\"contact-us.html\">Contact Us</a></li>

                                    <li><a href=\"{{ path('fos_user_security_logout') }}\">Logout</a></li>

                                </ul>
                            </div>
                        </div>
                        <!-- /.navbar-collapse -->
                    </nav>
                    <!-- END MAIN MENU -->
                </div>
            </div>
        </div>
    </div>
    <!-- Start Particle area -->

    {% block entree %}

    {% endblock %}
    <!-- End Particle area -->
</header>

<div class=\"container\" style=\"margin-top: 56px;padding: 50px 0;\">
    {% block containt %}

    {% endblock %}
</div>



<section id=\"footer\" class=\"footer\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-3\">
                <div class=\"logo pt-0\"><a href=\"index.html\">SWAT</a></div>
                <p class=\"font-w-6 pt-20 font-15 ln-h-30\"><span class=\"Color-b\">SWAT</span> is a fully responsive
                    Multipurpose Bootstrap 3 Template built for web-designers, web-developers, business and any
                    other creative people to build Bootstrap based websites.</p>
            </div>
            <div class=\"col-md-3\">
                <div class=\"section-title-2\">
                    <h3>UseFull Links</h3>
                </div>
                <div class=\"sidebar-post pt-15\">
                    <ul>
                        <li><a href=\"#\">Home Page Variations</a></li>
                        <li><a href=\"#\">Features Typography</a></li>
                        <li><a href=\"#\">Recent Blogs or News</a></li>
                        <li><a href=\"#\">Single and Portfolios</a></li>
                        <li><a href=\"#\">Company History</a></li>
                        <li><a href=\"#\">Different & Unique Pages</a></li>
                    </ul>
                </div>
            </div>
            <div class=\"col-md-3\">
                <div class=\"section-title-2\">
                    <h3>Photo Gallery</h3>
                </div>
                <div class=\"sidebar-gallery\">

                </div>
            </div>
            <div class=\"col-md-3\">
                <div class=\"section-title-2\">
                    <h3>Newsletter</h3>
                </div>
                <div class=\"footer-address\">
                    <p class=\"font-w-6\">Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry.</p>
                    <p class=\"font-w-6\"><span class=\"Color-b\">Street :</span> Orlando, Florida, USA</p>
                    <p class=\"font-w-6\"><span class=\"Color-b\">Email :</span> email@example.com</p>
                    <p class=\"font-w-6\"><span class=\"Color-b\">Phone :</span> +880123456789</p>
                </div>
                <div class=\"footer-social pt-15\">
                    <ul class=\"top-social\">
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-facebook\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-twitter\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-pinterest\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-dribbble\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-linkedin\"></i></a></li>
                        <li><a href=\"#\" target=\"_blank\"><i class=\"fa fa-rss\"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Contact end-->
<footer>
    <div class=\"clearfix\"></div>
    <div class=\"container\">
        <p class=\"text-center pt-10\">&copy; Copyright
            <script>
                var d = new Date();
                document.write(d.getFullYear());
            </script>
            SWAT | All Rights Reserved.
        </p>
    </div>
</footer>

{% block javascripts %}
    <script src=\"{{ asset ('user/assets/jquery/jquery-3.2.1.min.js') }}\"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src=\"{{ asset ('user/assets/bootstrap/js/bootstrap.min.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/easing/jquery.easing.min.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/isotope/jquery.isotope.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/jquery/imagesloaded.pkgd.min.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/wow/wow.min.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/slicknav/jquery.slicknav.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/particle/particles.min.js') }}\"></script>

    <script src=\"{{ asset ('user/assets/owlcarousel/js/owl.carousel.min.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/jquery/jquery.magnific-popup.min.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/number-animation/jquery.animateNumber.min.js') }}\"></script>
    <!-- Contact Form Script -->
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js\"></script>
    <script src=\"{{ asset ('user/assets/contact-form/js/validator.min.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/contact-form/js/form-scripts.js') }}\"></script>
    <script src=\"{{ asset ('user/assets/jquery/plugins.js') }}\"></script>
    <script src=\"{{ asset ('user/js/custom.js') }}\"></script>

{% endblock %}

{% block javascripts2 %}

    <script src=\"{{ asset ('user/assets/particle/app.js') }}\"></script>

{% endblock %}
</body>
</html>

", "EspritEntraideBundle::layout.html.twig", "C:\\wamp64\\www\\EspritEntraide\\src\\EspritEntraideBundle\\Resources\\views\\layout.html.twig");
    }
}
