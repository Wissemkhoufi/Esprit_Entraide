/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.pidev.gui.spotted;

import ca.weblite.codename1.components.ckeditor.CKeditor;
import ca.weblite.codename1.components.ckeditor.CKeditor2;
import com.codename1.components.InteractionDialog;
import com.codename1.components.SpanLabel;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.Font;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.Toolbar;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import com.codename1.ui.validation.LengthConstraint;
import com.codename1.ui.validation.Validator;
import com.mycompany.myapp.MyApplication;
import edu.pidev.entities.Publication;
import static edu.pidev.gui.spotted.ListPublication.desc_static;
import static edu.pidev.gui.spotted.ListPublication.id;
import static edu.pidev.gui.spotted.ListPublication.tags_static;
import edu.pidev.services.PublicationServices;
import java.util.ArrayList;

/**
 *
 * @author Seif BelHadjAli
 */
public class ModifPublication {

    Form f;
    SpanLabel lbDesc;
    SpanLabel lbTags;
    Button btnModif;
    TextArea desc_p;
    TextField tags;
    CKeditor editor;
    private Resources theme;
    ArrayList<String> motFiltre;

    public ModifPublication() {
        theme = UIManager.initFirstTheme("/theme");

//            this.getF().getToolbar().addMaterialCommandToLeftBar("Back", FontImage.MATERIAL_HOTEL, b -> {
//            f.showBack();
//        });
        int idx = ListPublication.id;
        String descx = ListPublication.desc_static;
        String tagsx = ListPublication.tags_static;

        System.out.println("id publcation = " + idx);
        System.out.println("desc publcation = " + descx);
        System.out.println("tags publcation = " + tagsx);
        f = new Form("Modifier Publication", BoxLayout.y());
        motFiltre = new ArrayList<>();
        motFiltre.add("Mot1");
        motFiltre.add("Mot2");
        motFiltre.add("Mot3");
//         PublicationServices ps = new PublicationServices();
//        ArrayList<Publication> listePublication = ps.afficher();
//         
        // for (Publication item : listePublication) {
        lbDesc = new SpanLabel("Contenue de la publication du modification");
        lbTags = new SpanLabel("Tags");
        desc_p = new TextArea();
         editor = new CKeditor();
 editor.initAndWait();

      
        editor.setPreferredH(180);
        editor.setHeight(20);
        editor.setData("<p>Hello seif</p>");
        
        desc_p.getStyle().setFgColor(0xff000);
        desc_p.setText(descx);
        tags = new TextField();
        tags.setText(tagsx);
        btnModif = new Button("Modifier", "GreenButton");

        int size = Display.getInstance().convertToPixels(6, true);
        Font materialFont = FontImage.getMaterialDesignFont();

        materialFont = materialFont.derive(size, Font.STYLE_PLAIN);
        f.refreshTheme();

        Validator val = new Validator();
        val.addConstraint(desc_p, new LengthConstraint(0, "vous devez ajouter au moins  caractere")).addConstraint(tags, new LengthConstraint(0));

        val.addSubmitButtons(btnModif);
        f.refreshTheme();

        btnModif.setIcon(FontImage.create("\uE254", btnModif.getUnselectedStyle(), materialFont));

        btnModif.addActionListener((e) -> {
                        boolean ok = false;
            boolean ok2 = false;
            if (editor.getData().equals("")) {
                Dialog.show("Erreur de saisie", "Veuillez remlpir le champ description !", "fermer", null);
                
                ok2 = false;
                
            } else {
                ok2 = true;
            }
           
                        if (tags.getText().equals("")) {
                Dialog.show("Erreur de saisie", "Veuillez remlpir le champ tags !", "fermer", null);
                
                ok = false;
                
            } else {
                ok = true;
            }
                        
            if (ok && ok2 && FilterMe()) {
                f.refreshTheme();

                val.addSubmitButtons(btnModif);
                f.refreshTheme();

                PublicationServices ps = new PublicationServices();
                Publication pub = new Publication();
                pub.setDesc_p(editor.getData());
                pub.setTags(tags.getText());
                ps.modifPublication(pub);

                InteractionDialog dlg = new InteractionDialog("Succés");
                dlg.setLayout(new BorderLayout());

                Label successLabel = new Label("Publication Modifie avec succés");
                successLabel.getStyle().setFgColor(0xff000);
//ss
                dlg.add(BorderLayout.CENTER, successLabel);
                Button close = new Button("Fermer");
                close.addActionListener((ee) -> dlg.dispose());
                dlg.addComponent(BorderLayout.SOUTH, close);
                Dimension pre = dlg.getContentPane().getPreferredSize();
                dlg.show(110, 120, 0, 0);
                PublicationServices pst = new PublicationServices();

                ListPublication listpublication = new ListPublication();
                pst.afficher();

//            listpublication.getF().getToolbar().addMaterialCommandToLeftBar("Back", FontImage.MATERIAL_HOTEL, b -> {
//                f.showBack();
//
//            });
                listpublication.getF().show();
                listpublication.getF().getToolbar().addCommandToLeftBar("retour", theme.getImage("back-command.png"), b -> {
                    f.showBack();

                });
            }
        });
        //}
        Container c1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        
        c1.add(lbDesc);
        c1.add(editor);
        editor.setData(""+descx);

        //c1.add(desc_p);
        c1.add(lbTags);
        c1.add(tags);
        c1.add(btnModif);
        f.add(c1);
    }

    public Boolean FilterMe() {
        boolean ok2 = true;
        String original = editor.getData();
        String original2 = tags.getText();
        System.out.println("Original txt = " + original);
        for (String abc : motFiltre) {
            // for (String f2 : aps558) {
            if (original.indexOf(abc) > -1 || original2.indexOf(abc) > -1) {
                System.err.println("ERREURDE SAISIE");
                Dialog.show("Erreur de saisie", "Vous avez choisie une mot interdit :" + abc + " !", "Ok", null);
                ok2 = false;
                return ok2;
            } else {
                System.out.println("tout va bien");
            }
            //}

        }
        return ok2;

    }

    public Form getF() {
        return f;
    }

    public void setF(Form f) {
        this.f = f;
    }

}
