/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.pidev.gui.spotted;

import ca.weblite.codename1.components.ckeditor.CKeditor;
import ca.weblite.codename1.components.ckeditor.CKeditor2;
import com.codename1.capture.Capture;
import com.codename1.components.InfiniteProgress;
import com.codename1.components.InteractionDialog;
import com.codename1.components.SpanLabel;
import com.codename1.io.MultipartRequest;
import com.codename1.io.NetworkManager;
import com.codename1.l10n.SimpleDateFormat;
import com.codename1.ui.Button;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.Font;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.Toolbar;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import com.codename1.ui.validation.LengthConstraint;
import com.codename1.ui.validation.RegexConstraint;
import com.codename1.ui.validation.Validator;
import edu.pidev.entities.Commentaire;
import edu.pidev.entities.Publication;
import edu.pidev.services.PublicationServices;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Seif BelHadjAli
 */
public class AjoutPublication {

    String fileNameInServer;
    Form f;
    SpanLabel lbDesc;
    SpanLabel lbTags;
    Button btnAjout;
    TextField desc_p;
    TextField tags;
    private Resources theme;
    ArrayList<String> motFiltre;
    ArrayList<String> aps558;
    CKeditor editor;

    public AjoutPublication() {
        fileNameInServer = "";
        theme = UIManager.initFirstTheme("/theme");
        Container c0 = new Container(new BoxLayout(BoxLayout.X_AXIS_NO_GROW));
        String html;

        editor = new CKeditor();

        Label lb1 = new Label("Ecrire ici..");
        Button btnValid = new Button("Bonjour CKEDITOR");

        editor.initAndWait();

        editor.setPreferredH(180);
        Button btn11 = new Button("Tets");
        // Enable Toolbar on all Forms by default
        Toolbar.setGlobalToolbar(true);

        f = new Form("Ajout Publication", BoxLayout.y());
        Form f2 = new Form("Ajout Publication Texto", BoxLayout.y());
        Form f3 = new Form("Ajout Publication Photo", BoxLayout.y());

        Container c00 = new Container(new BoxLayout(BoxLayout.X_AXIS));
        f2.add(lb1);
        c00.add(editor);
        f2.add(c00);
        Container c1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        Container c2 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        c0.setVisible(true);
        c1.setVisible(false);
        c2.setVisible(false);
        Label txtP1 = new Label("");
        Label txtP2 = new Label("");
        Button btn1 = new Button("Publication");
        Button btn2 = new Button("Photo");

        lbDesc = new SpanLabel("Contenue de la publication");
        SpanLabel lbImage = new SpanLabel("importer une image");
        lbTags = new SpanLabel("Tags");
        SpanLabel lbTags2 = new SpanLabel("Tags");

        desc_p = new TextField();
        motFiltre = new ArrayList<>();
        motFiltre.add("Mot1");
        motFiltre.add("Mot2");
        motFiltre.add("Mot3");
        desc_p.getStyle().setBorder(Border.createLineBorder(1, 1));
        desc_p.getStyle().setFgColor(0xff000);
        tags = new TextField();
        TextField tags2 = new TextField();
        btnAjout = new Button("Ajout Publication", "SaveButton");
        Font materialFont = FontImage.getMaterialDesignFont();
        int size = Display.getInstance().convertToPixels(6, true);
        materialFont = materialFont.derive(size, Font.STYLE_PLAIN);

        btnAjout.setIcon(FontImage.create("\uE161", btnAjout.getUnselectedStyle(), materialFont));
        Button btnUploadImage = new Button("upload");
        materialFont = materialFont.derive(size, Font.STYLE_PLAIN);

        btnUploadImage.setIcon(FontImage.create("\uE161", btnUploadImage.getUnselectedStyle(), materialFont));

        btnUploadImage.addActionListener((evt) -> {
            try {
                fileNameInServer = "";

                MultipartRequest cr = new MultipartRequest();
                String filepath = Capture.capturePhoto(-1, -1);
                cr.setUrl("http://localhost:8081/PIDEV-final2/uploadimage.php");
                cr.setPost(true);
                String mime = "image/jpeg";
                cr.addData("file", filepath, mime);
                String out = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
                cr.setFilename("file", out + ".jpg");//any unique name you want

                fileNameInServer += out + ".jpg";
                System.err.println("path2 =" + fileNameInServer);
                InfiniteProgress prog = new InfiniteProgress();
                Dialog dlg = prog.showInifiniteBlocking();
                cr.setDisposeOnCompletion(dlg);
                NetworkManager.getInstance().addToQueueAndWait(cr);
            } catch (IOException ex) {
                System.out.println(ex.getMessage() + "error image");
            }
        });
        Button btnAjout2 = new Button("Ajout Photo", "SaveButton");

        materialFont = materialFont.derive(size, Font.STYLE_PLAIN);

        btnAjout2.setIcon(FontImage.create("\uE161", btnAjout2.getUnselectedStyle(), materialFont));

        btnAjout2.addActionListener((e) -> {
            boolean ok = false;
            boolean ok2 = false;
            if (tags2.getText().equals("")) {
                Dialog.show("Erreur de saisie", "Veuillez remlpir le champ tags !", "fermer", null);

                ok = false;
                System.out.println("Champs desc vide alos ok (false) = " + ok);

            } else {
                ok = true;
            }

            if (fileNameInServer.equals("")) {
                Dialog.show("Erreur de saisie", "Vous devez importer une image!", "fermer", null);

                ok = false;

            } else {
                ok = true;
            }

            if (ok && FilterMe2()) {

                PublicationServices ps = new PublicationServices();
                Publication pub = new Publication();
                pub.setImage(fileNameInServer);
                pub.setTags(tags2.getText());
                pub.setDesc_p("image");
                ps.ajoutPublication(pub);

                InteractionDialog dlg = new InteractionDialog("Succés");
                dlg.setLayout(new BorderLayout());

                Label successLabel = new Label("Publication ajoute avec succés");
                successLabel.getStyle().setFgColor(0xff000);

                dlg.add(BorderLayout.CENTER, successLabel);
                Button close = new Button("Fermer");
                editor.setData("");
                tags2.setText("");
                fileNameInServer = "";
                close.addActionListener((ee) -> dlg.dispose());
                dlg.addComponent(BorderLayout.SOUTH, close);
                Dimension pre = dlg.getContentPane().getPreferredSize();
                dlg.show(110, 120, 0, 0);

                PublicationServices pst = new PublicationServices();

                pst.afficher();

                ListPublication listpublication = new ListPublication();

                listpublication.getF().show();
                listpublication.getF().getToolbar().addCommandToLeftBar("retour", theme.getImage("back-command.png"), b -> {
                    f.showBack();

                });
            }
        });

        txtP1.setVisible(true);
        txtP2.setVisible(true);
        btn1.setVisible(true);
        btn2.setVisible(true);
        f2.add(txtP1);
        f3.add(txtP2);
        desc_p.setHint("Ecirire ici...");

        tags.setHint("tags ici...");
        //f2.add(desc_p);
        f2.add(lbTags);
        f2.add(tags);
        f2.add(btnAjout);

        f3.add(lbImage);
        f3.add(btnUploadImage);
        f3.add(lbTags2);
        tags2.setHint("tags ici...");

        f3.add(tags2);
        f3.add(btnAjout2);
        Validator val = new Validator();
//ss
        //val.addConstraint(editor, new LengthConstraint(2, "ssssss")).addConstraint(tags, new LengthConstraint(2));
        val.addSubmitButtons(btnAjout);
        f.refreshTheme();
        aps558 = new ArrayList<>();

//        desc_p.addDataChangeListener((i1, i2) -> {
////            String alpha = desc_p.getText();
////
////            String a2 = " ";
////            if (alpha.endsWith(" ")) {
////
////                System.out.println("Vous avez tapez une espace");
////                System.out.println("Alpha 1 = " + alpha);
////                aps558.add(alpha);
////                alpha = " ";
////                System.out.println("Alpha 1 = " + alpha);
////
////            } else {
////                System.out.println("you have added this " + desc_p.getText() + " to the list+" + aps558);
////                alpha = " ";
////                System.out.println("Alpha 1 = " + alpha);
////
////            }
//
//        });
        btnAjout.addActionListener((e) -> {

            //val.addConstraint(editor, new LengthConstraint(2)).addConstraint(tags, new LengthConstraint(2));
            val.addSubmitButtons(btnAjout);
            f.refreshTheme();
            f.refreshTheme();
            System.out.println("you have passed here !");
            System.out.println("ok = ");
            boolean ok = false;
            boolean ok2 = false;
            System.out.println("desc con = "+editor.getData());
            if (editor.getData().equals("")) {
                Dialog.show("Erreur de saisie", "Veuillez remplir le champ description !", "fermer", null);
                ok2 = false;

            } else {
                ok2 = true;
            }
            if (tags.getText().equals("")) {
                Dialog.show("Erreur de saisie", "Veuillez remlpir le champ tags !", "fermer", null);

                ok = false;
                System.out.println("Champs desc vide alos ok (false) = " + ok);

            } else {
                ok = true;
            }
            if (ok && ok2 && FilterMe()) {
                System.out.println("les deux champs sont correctement remplie (true) alors ok  = " + ok);

                PublicationServices ps = new PublicationServices();
                Publication pub = new Publication();
                pub.setDesc_p(editor.getData());
                pub.setTags(tags.getText());
                pub.setImage("");
                ps.ajoutPublication(pub);

                InteractionDialog dlg = new InteractionDialog("Succés");
                dlg.setLayout(new BorderLayout());

                Label successLabel = new Label("Publication ajoute avec succés");
                successLabel.getStyle().setFgColor(0xff000);

                dlg.add(BorderLayout.CENTER, successLabel);
                Button close = new Button("Fermer");
                editor.setData("");
                tags.setText("");
                close.addActionListener((ee) -> dlg.dispose());
                dlg.addComponent(BorderLayout.SOUTH, close);
                Dimension pre = dlg.getContentPane().getPreferredSize();
                dlg.show(110, 120, 0, 0);

                PublicationServices pst = new PublicationServices();

                pst.afficher();

                ListPublication listpublication = new ListPublication();

                listpublication.getF().show();
                listpublication.getF().getToolbar().addCommandToLeftBar("retour", theme.getImage("back-command.png"), b -> {
                    f.showBack();

                });
            }

        });

        btn1.addActionListener((e) -> {
            f2.show();

        });

        btn2.addActionListener((e) -> {
            f3.show();

        });

        f2.getToolbar().addCommandToLeftBar("retour", theme.getImage("back-command.png"), b -> {
            f.showBack();

        });

        f3.getToolbar().addCommandToLeftBar("retour", theme.getImage("back-command.png"), b -> {
            f.showBack();

        });

        f.add(btn1);
        //f.add(b0x);
        f.add(btn2);
        f.show();

        Button btnAjoutPublication = new Button("Ajout Publication");

        materialFont = materialFont.derive(size, Font.STYLE_PLAIN);

        btnAjoutPublication.setIcon(FontImage.create("\uE161", btnAjoutPublication.getUnselectedStyle(), materialFont));

        Button btnAjoutPhoto = new Button("Ajout Photo");

        materialFont = materialFont.derive(size, Font.STYLE_PLAIN);

        btnAjoutPhoto.setIcon(FontImage.create("\uE161", btnAjoutPhoto.getUnselectedStyle(), materialFont));

        Button btnRetour = new Button("Retour");

        c0.add(btnAjoutPublication);
        c0.add(btnAjoutPhoto);
        c1.add(btnRetour);
//        c2.add(btnRetour);

        btnAjoutPublication.addActionListener((e) -> {
            System.out.println("Begin Ajout PUBLICATION");
            c0.setVisible(false);
            c1.setVisible(true);
            //btnRetour.setVisible(true);
            System.out.println("End Ajout PUBLICATION");

        });

        btnAjoutPhoto.addActionListener((e) -> {
            System.out.println("Begin Ajout Photo Publication");

            c0.setVisible(false);
            c2.setVisible(true);
            System.out.println("End Ajout Photo Publication");

        });
//
//        btnRetour.addActionListener((e) -> {
//            System.out.println("Begin Retour Publication");
//
//            c0.setVisible(true);
//            c1.setVisible(false);
//            c2.setVisible(false);
//            System.out.println("End Retour Publication");
//
//        });
//
//        lbDesc = new SpanLabel("Contenue de la publication");
//        lbTags = new SpanLabel("Tags");
//
//        desc_p = new TextArea();
//        desc_p.getStyle().setBorder(Border.createLineBorder(1, 1));
//        desc_p.getStyle().setFgColor(0xff000);
//        tags = new TextField();
//        btnAjout = new Button("Ajout Publication");
//
//        c1.add(lbDesc);
//        c1.add(desc_p);
//        c1.add(lbTags);
//        c1.add(tags);
//        c1.add(btnAjout);
//        f.add(c0);
//        f.add(c1);
//        f.add(c2);
//
//        btnAjout.addActionListener((e) -> {
//            PublicationServices ps = new PublicationServices();
//            Publication pub = new Publication();
//            pub.setDesc_p(desc_p.getText());
//            pub.setTags(tags.getText());
//            ps.ajoutPublication(pub);
//
//            InteractionDialog dlg = new InteractionDialog("Succés");
//            dlg.setLayout(new BorderLayout());
//
//            Label successLabel = new Label("Publication ajoute avec succés");
//            successLabel.getStyle().setFgColor(0xff000);
//
//            dlg.add(BorderLayout.CENTER, successLabel);
//            Button close = new Button("Fermer");
//            close.addActionListener((ee) -> dlg.dispose());
//            dlg.addComponent(BorderLayout.SOUTH, close);
//            Dimension pre = dlg.getContentPane().getPreferredSize();
//            dlg.show(110, 120, 0, 0);
//            ListPublication listpublication = new ListPublication();
//            listpublication.getF().show();
//
//        });
    }

    public Boolean FilterMe2() {
        boolean ok2 = true;
        String original2 = tags.getText();
        System.out.println("Original txt = " + original2);
        for (String abc : motFiltre) {
            // for (String f2 : aps558) {
            if (original2.indexOf(abc) > -1) {
                System.err.println("ERREURDE SAISIE");
                Dialog.show("Erreur de saisie", "Vous avez choisie une mot interdit !" + abc + " !", "Ok", null);
                ok2 = false;
                return ok2;
            } else {
                System.out.println("tout va bien");
            }
            //}

        }
        return ok2;

    }

    public Boolean FilterMe() {
        boolean ok2 = true;
        String original = editor.getData();
        String original2 = tags.getText();
        System.out.println("Original txt = " + original);
        for (String abc : motFiltre) {
            // for (String f2 : aps558) {
            if (original.indexOf(abc) > -1 || original2.indexOf(abc) > -1) {
                System.err.println("ERREURDE SAISIE");
                Dialog.show("Erreur de saisie", "Vous avez choisie une mot interdit !" + abc + " !", "Ok", null);
                ok2 = false;
                return ok2;
            } else {
                System.out.println("tout va bien 00");
            }
            //}

        }
        return ok2;

    }

    public Form getF() {
        return f;
    }

    public void setF(Form f) {
        this.f = f;
    }
}
