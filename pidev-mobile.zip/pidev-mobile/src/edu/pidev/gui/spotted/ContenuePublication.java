/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.pidev.gui.spotted;

import ca.weblite.codename1.components.ckeditor.CKeditor2;
import com.codename1.components.InteractionDialog;
import com.codename1.components.SpanLabel;
import com.codename1.notifications.LocalNotification;
import com.codename1.ui.Button;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.EncodedImage;
import com.codename1.ui.Font;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.Slider;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.Toolbar;
import com.codename1.ui.URLImage;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.events.DataChangedListener;
import com.codename1.ui.events.FocusListener;
import com.codename1.ui.events.ScrollListener;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import com.codename1.ui.validation.LengthConstraint;
import com.codename1.ui.validation.Validator;
import com.mycompany.myapp.MyApplication;
import edu.pidev.entities.Commentaire;
import edu.pidev.entities.Publication;
import edu.pidev.entities.Rating;
import static edu.pidev.gui.spotted.ListPublication.desc_static;
import static edu.pidev.gui.spotted.ListPublication.id;
import static edu.pidev.gui.spotted.ListPublication.tags_static;
import static edu.pidev.gui.spotted.ListPublication.image_static;
import edu.pidev.services.PublicationServices;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Seif BelHadjAli
 */
public class ContenuePublication implements ScrollListener {

    Form f;
    SpanLabel lbDesc;
    SpanLabel lbTags;
    Button btnModif;
    TextArea desc_p;
    TextField tags;
    Container cCommentaire2;
    private Resources theme;
    private EncodedImage ei;
    private EncodedImage ei1;
    ArrayList<String> motFiltre;
    public static int idP, idC;
    Validator val;
    ArrayList<Commentaire> listeCommentaire;
    Container cCommentaire, cButtons, cButtons2;
    TextField Commtxt;

    public ContenuePublication() {

        theme = UIManager.initFirstTheme("/theme");
        Toolbar.setGlobalToolbar(true);
        motFiltre = new ArrayList<>();
        motFiltre.add("Mot1");
        motFiltre.add("Mot2");
        motFiltre.add("Mot3");
        try {
            ei = EncodedImage.create("/WorldCup.PNG");
            ei1 = EncodedImage.create("/WorldCup.PNG");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
//            this.getF().getToolbar().addMaterialCommandToLeftBar("Back", FontImage.MATERIAL_HOTEL, b -> {
//            f.showBack();
//        });
        int idx = ListPublication.id;
        String descx = ListPublication.desc_static;
        String tagsx = ListPublication.tags_static;
        String imagex = ListPublication.image_static;

        f = new Form("Contenue Publication", BoxLayout.y());
        lbDesc = new SpanLabel("Contenue de la publication ");
        lbTags = new SpanLabel("Tags");
        Label ImagetxtPhoto = new Label();

        SpanLabel desc_txt = new SpanLabel();
        Container c1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        Container c2 = new Container(new BoxLayout(BoxLayout.Y_AXIS));

        SpanLabel lbAjoutCommentaire = new SpanLabel();
        Commtxt = new TextField();
        Commtxt.setHint("Ajouter votre commentaire ici");

        Button AjoutCommentaire = new Button("Commenter", "SaveButton");
        c2.add(lbAjoutCommentaire);
        c2.add(Commtxt);
        c2.add(AjoutCommentaire);
        f.refreshTheme();

        val = new Validator();
        f.refreshTheme();

        //Commtxt.setConstraint(TextArea.);
        val.addConstraint(Commtxt, new LengthConstraint(2));
        val.addSubmitButtons(AjoutCommentaire);

        Commtxt.addDataChangeListener((i1, i2) -> {

            Validator valx = new Validator();
            //Commtxt.setConstraint(TextArea.);
            valx.addConstraint(Commtxt, new LengthConstraint(2));
            val.addSubmitButtons(AjoutCommentaire);

            valx.addConstraint(Commtxt, new LengthConstraint(2));
            val.addSubmitButtons(AjoutCommentaire);

            System.out.println("Good ! you are changed me ! new text = " + Commtxt.getText());

        });
        f.refreshTheme();

        PublicationServices ps = new PublicationServices();
        listeCommentaire = ps.afficherCommentaire();
        // SpanLabel newCom = new SpanLabel("");

        if (descx.equals("")) {
            String imagex2 = ListPublication.image_static;

            System.out.println("image 00" + imagex);
            System.out.println("type image clicked");
            System.err.println("ok -- http://localhost:8081/PIDEV-final2/web/uploads/images/" + imagex);
            System.err.println("ko -- http://localhost:8081/PIDEV-final2/web/uploads/images/" + image_static);
            Image img;
            try {
                String imagex3 = ListPublication.image_static;

                img = URLImage.createToStorage(ei, imagex,
                        imagex + "6e8e28840394ae17f3bf2c6d0a0d317a.jpeg", URLImage.RESIZE_FAIL);

//                img.scale(100, 100);
//
//                img.scaledWidth(20);
                ImagetxtPhoto.setIcon(img);
//                img.scale(100, 100);
                ImagetxtPhoto.setPreferredH(100);
                ImagetxtPhoto.setPreferredW(100);
                c1.add(ImagetxtPhoto);

            } catch (NullPointerException ex) {
                System.out.println(ex.getMessage() + " Image vide");
            }
        } else {

        }

        SpanLabel tags_txt = new SpanLabel();
        desc_txt.setText(descx);
        tags_txt.setText(tagsx);

        //}
        //c1.add(lbDesc);
   Container c0me = new Container(new BoxLayout(BoxLayout.X_AXIS_NO_GROW));
                    CKeditor2 editor = new CKeditor2();

                    editor.initAndWait();

      
        editor.setPreferredH(80);
        editor.setHeight(20);
        c0me.setHeight(20);
        editor.setData("<p>Hello seif</p>");
        
        c1.add(editor);
        editor.setData(desc_txt.getText());
        editor.setEnabled(false);
        
        //c1.add(lbTags);
        c1.add("#"+tags_txt.getText());
        PublicationServices ptyd = new PublicationServices();
        
        ArrayList<Rating> listeRating = ptyd.afficherRating();
        Rating item;
        System.out.println("<===============================>" + listeRating + "");
   
                        c1.add(FlowLayout.encloseCenter(createStarRankSlider2(0)));

//        for (Rating rat : listeRating) {
//            System.out.println("id user = RATING " + rat.getId_user());
//            System.out.println("id publication =  RATING " + rat.getId_publication());
//            int nRate = Integer.parseInt(rat.getRating());
//            if (rat.getId_user() == 26 && rat.getId_publication() == idx) {
//                System.out.println("vous avez deja voter pour cette publication");
//                c1.add(new Label("Vous avez voter "+nRate+" pour cette publication"));
//
//
//            } else {
//
//                System.err.println("Bonjour RATING");
//
//                //c1.add(FlowLayout.encloseCenter(createStarRankSlider(0)));
//
//            }
//        }

        // c2.add(newCom);
        c1.add(FlowLayout.encloseCenter(createStarRankSlider(0)));
        f.add(c1);
        f.add(c2);

        for (Commentaire item05 : listeCommentaire) {

            cCommentaire = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            cButtons = new Container(new BoxLayout(BoxLayout.X_AXIS));
            SpanLabel conCommtxt = new SpanLabel();
            conCommtxt.setText(item05.getContent_comm());

            Button btnModif = new Button("", "GreenButton");
            Button btnSupprimer = new Button("", "RedButton");
            Button btnSave = new Button("", "SaveButton");

            TextField zoneComm = new TextField();
            zoneComm.setText(item05.getContent_comm());
            zoneComm.setPreferredH(50);
            zoneComm.setVisible(false);

            btnSupprimer.addActionListener((e) -> {

                if (Dialog.show("Delete", "Are you sure?", "Yes", "No")) {
                    System.out.println("deleted");
                    idC = item05.getId();
                    System.out.println("id c =" + idC);
                    PublicationServices ps2 = new PublicationServices();
                    Commentaire pub = new Commentaire();
                    ps.suppCommentaire(pub);

                    InteractionDialog dlg = new InteractionDialog("Succés");
                    dlg.setLayout(new BorderLayout());

                    Label successLabel = new Label("Commentaire supp");
                    successLabel.getStyle().setFgColor(0xff000);

                    dlg.add(BorderLayout.CENTER, successLabel);
                    Button close = new Button("Fermer");
                    close.addActionListener((ee) -> dlg.dispose());
                    dlg.addComponent(BorderLayout.SOUTH, close);
                    Dimension pre = dlg.getContentPane().getPreferredSize();
                    dlg.show(110, 120, 0, 0);
                    f.revalidate();
                    PublicationServices pst = new PublicationServices();

                    ContenuePublication contenuepublication = new ContenuePublication();
                    contenuepublication.getF().show();
                    contenuepublication.getF().getToolbar().addCommandToLeftBar("retour", theme.getImage("back-command.png"), b -> {
                        f.showBack();

                    });

                } else {
                    System.out.println("not deleted");
                }

                //f.show();
            });

            cCommentaire.add(conCommtxt);

            zoneComm.setEditable(true);
            zoneComm.setEnabled(false);
            btnSave.setVisible(false);
            zoneComm.setEditable(false);

            btnModif.addActionListener((e) -> {
                btnSave.setVisible(true);
                btnModif.setVisible(false);

                // f.scrollChang
                zoneComm.setEnabled(true);

                zoneComm.setVisible(true);
                // alech rtmovi feha cCommentaire.removeComponent(conCommtxt);
                conCommtxt.setVisible(false);
                conCommtxt.setEnabled(false);
                cCommentaire.refreshTheme();
                zoneComm.setEditable(true);

                System.out.println("clicked modfiied button and hide label");

                //  cCommentaire.add(zoneComm);
            });
            System.out.println("Zone comme txt = " + zoneComm.getText());
            zoneComm.setConstraint(TextField.ANY);
            if (zoneComm.getText().equals("")) {
                System.err.println("FORBIDDEN !");
                btnSave.setEnabled(false);

            } else {
                System.out.println("you are allowed to add this");
                btnSave.setEnabled(true);

            }
            zoneComm.addDataChangeListener((i1, i2) -> {

                System.out.println("Zone comme txt = " + zoneComm.getText());
                if (zoneComm.getText().equals("")) {
                    System.err.println("FORBIDDEN !");
                    btnSave.setEnabled(false);

                } else {
                    System.out.println("you are allowed to add this");
                    btnSave.setEnabled(true);

                }

                System.out.println(item05.getContent_comm() + " <====== w");
            });

            btnSave.addActionListener((e) -> {
                boolean ok = false;
                boolean ok2 = false;
                boolean testOk = false;

                if (zoneComm.getText().equals("")) {
                    ok = false;
                    System.out.println("Champs desc vide alos ok (false) = " + ok);

                } else {
                    ok = true;
                }

                String original = zoneComm.getText();
                System.out.println("Original txt = " + original);
                for (String abc : motFiltre) {
                    // for (String f2 : aps558) {
                    if (original.indexOf(abc) > -1) {
                        testOk = true;
                        Dialog.show("Erreur de saisie", "Vous avez choisie une mot interdit !" + testOk + " !", "Ok", null);

                    }
                    //}

                }
                if (!testOk) {
                    ok = false;
                    System.out.println("tout va bien");
                    btnSave.setVisible(false);
                    btnModif.setVisible(true);

                    idC = item05.getId();
                    zoneComm.setEnabled(false);

                    zoneComm.setEditable(false);

                    zoneComm.setVisible(false);
                    conCommtxt.setVisible(true);

                    if (conCommtxt.getText().equals(zoneComm.getText())) {
                        System.out.println("c kifkif");

                    } else {
                        conCommtxt.setText("" + zoneComm.getText());

                        Commentaire com1 = new Commentaire();
                        com1.setContent_comm(zoneComm.getText());
                        PublicationServices psty = new PublicationServices();
                        psty.modifCommentaire(com1);

                        Dialog.show("Terminé", "Modification terminé avec succes", "Fermer", null);
                        //int REPEAT_NONE = LocalNotification.REPEAT_NONE;
                        LocalNotification n = new LocalNotification();
                        n.setId("TGN-notifications");
                        n.setAlertBody("Vous avez modifier un commentaire!");
                        n.setAlertTitle(" Comment!");
                        //n.setAlertSound("beep-01a.mp3");
                        Display.getInstance().scheduleLocalNotification(
                                n,
                                System.currentTimeMillis() + 10, // fire date/time
                                LocalNotification.REPEAT_NONE // Whether to repeat and what frequency
                        );
                        conCommtxt.setVisible(true);
                        conCommtxt.setEnabled(true);
                        System.out.println("c not kifkif");

                    }
                }

                System.out.println("clicked saved button and saved label");

            });

            int size = Display.getInstance().convertToPixels(6, true);
            Font materialFont = FontImage.getMaterialDesignFont();

            materialFont = materialFont.derive(size, Font.STYLE_PLAIN);
            btnModif.setIcon(FontImage.create("\uE254", btnModif.getUnselectedStyle(), materialFont));
            btnSupprimer.setIcon(FontImage.create("\uE872", btnSupprimer.getUnselectedStyle(), materialFont));
            btnSave.setIcon(FontImage.create("\uE161", btnSave.getUnselectedStyle(), materialFont));

            //conCommtxt.setPreferredW(100);
            if (item05.getId_user() == 26) {
                cButtons.add(btnSupprimer);
                cButtons.add(btnModif);

            }

            cButtons.add(btnSave);

            cCommentaire.add(zoneComm);

            cCommentaire.add(cButtons);
            f.add(cCommentaire);

        }

        AjoutCommentaire.addActionListener((e) -> {
            Validator val2 = new Validator();

            boolean ok = false;

            if (FilterMe()) {

                val2.addConstraint(Commtxt, new LengthConstraint(2));
                val2.addSubmitButtons(AjoutCommentaire);

                System.out.println("it supposed to be NOT EMPTY:" + listeCommentaire);

                listeCommentaire.clear();

                System.out.println("it suppsed tp be empty :" + listeCommentaire);

                idP = idx;
                Commentaire com = new Commentaire();
                com.setContent_comm(Commtxt.getText());
                //newCom.setText("new added "+Commtxt.getText());
                ps.ajoutCommentaire(com);
                InteractionDialog dlg = new InteractionDialog("Succés");
                dlg.setLayout(new BorderLayout());

                Label successLabel = new Label("Commentaire ajoute avec succés");
                successLabel.getStyle().setFgColor(0xff000);

                dlg.add(BorderLayout.CENTER, successLabel);
                Button close = new Button("Fermer");
                f.setTintColor(0);

                Commtxt.setText("");

                close.addActionListener((ee) -> dlg.dispose());
                dlg.addComponent(BorderLayout.SOUTH, close);
                Dimension pre = dlg.getContentPane().getPreferredSize();
                dlg.show(110, 120, 0, 0);
                PublicationServices ps7 = new PublicationServices();

                listeCommentaire = ps7.afficherCommentaire();

                PublicationServices pst = new PublicationServices();

                ContenuePublication contenuepublication = new ContenuePublication();
                System.out.println("avant affichage");
                contenuepublication.getF().show();
                System.out.println("apres affichage");
                contenuepublication.getF().getToolbar().addCommandToLeftBar("retour", theme.getImage("back-command.png"), b -> {
                    f.showBack();

                });
            }
        });
        f.show();

    }

    private void initStarRankStyle(Style s, Image star) {
        s.setBackgroundType(Style.BACKGROUND_IMAGE_TILE_BOTH);
        s.setBorder(Border.createEmpty());
        s.setBgImage(star);
        s.setBgTransparency(0);
    }

    private Slider createStarRankSlider(int val8) {
        int idx = ListPublication.id;

        Slider starRank = new Slider();
        Label lb = new Label();

        starRank.setEditable(true);
        starRank.setMinValue(0);
        starRank.setMaxValue(5);
        Font fnt = Font.createTrueTypeFont("native:MainLight", "native:MainLight").
                derive(Display.getInstance().convertToPixels(5, true), Font.STYLE_PLAIN);
        Style s = new Style(0xffff33, 0, fnt, (byte) 0);
        Image fullStar = FontImage.createMaterial(FontImage.MATERIAL_STAR, s).toImage();
        s.setOpacity(100);
        s.setFgColor(0);
        Image emptyStar = FontImage.createMaterial(FontImage.MATERIAL_STAR, s).toImage();
        initStarRankStyle(starRank.getSliderEmptySelectedStyle(), emptyStar);
        initStarRankStyle(starRank.getSliderEmptyUnselectedStyle(), emptyStar);
        initStarRankStyle(starRank.getSliderFullSelectedStyle(), fullStar);
        initStarRankStyle(starRank.getSliderFullUnselectedStyle(), fullStar);
        starRank.setPreferredSize(new Dimension(fullStar.getWidth() * 5, fullStar.getHeight()));
        int id5 = ListPublication.id;
        starRank.addDataChangedListener(new DataChangedListener() {
            @Override
            public void dataChanged(int type, int index) {
                starRank.setEnabled(false);
                starRank.setEditable(false);
                System.out.println("Note " + starRank.getProgress());

                int con = starRank.getProgress();
                lb.setText("Note " + starRank.getProgress());
                System.out.println("Note " + starRank.getProgress());
                PublicationServices nps = new PublicationServices();
                Rating rating = new Rating();
                rating.setId_user(26);
                rating.setId_publication(id5);
                rating.setRating("" + starRank.getProgress());
                nps.ajoutRating(rating);
                starRank.setEnabled(false);
                starRank.setEditable(false);
                Dialog.show("Succes", "Vote terminé avec success !", "Fermer", null);

            }
        });
        starRank.setProgress(val8);
        return starRank;
    }

    private Slider createStarRankSlider2(int val8) {

        Slider starRank = new Slider();
        Label lb = new Label();

        starRank.setEditable(true);
        starRank.setMinValue(0);
        starRank.setMaxValue(5);
        Font fnt = Font.createTrueTypeFont("native:MainLight", "native:MainLight").
                derive(Display.getInstance().convertToPixels(5, true), Font.STYLE_PLAIN);
        Style s = new Style(0xffff33, 0, fnt, (byte) 0);
        Image fullStar = FontImage.createMaterial(FontImage.MATERIAL_STAR, s).toImage();
        s.setOpacity(100);
        s.setFgColor(0);
        Image emptyStar = FontImage.createMaterial(FontImage.MATERIAL_STAR, s).toImage();
        initStarRankStyle(starRank.getSliderEmptySelectedStyle(), emptyStar);
        initStarRankStyle(starRank.getSliderEmptyUnselectedStyle(), emptyStar);
        initStarRankStyle(starRank.getSliderFullSelectedStyle(), fullStar);
        initStarRankStyle(starRank.getSliderFullUnselectedStyle(), fullStar);
        starRank.setPreferredSize(new Dimension(fullStar.getWidth() * 5, fullStar.getHeight()));
                starRank.setEnabled(false);
                starRank.setEditable(false);
                starRank.setProgress(val8);
        return starRank;
    }

    private void showStarPickingForm() {
        Form hi = new Form("Star Slider", new BoxLayout(BoxLayout.Y_AXIS));
        hi.add(FlowLayout.encloseCenter(createStarRankSlider(0)));
        hi.show();
    }

    public Boolean FilterMe() {
        boolean ok2 = true;
        String original = Commtxt.getText();
        System.out.println("Original txt = " + original);
        for (String abc : motFiltre) {
            // for (String f2 : aps558) {
            if (original.indexOf(abc) > -1) {
                System.err.println("ERREURDE SAISIE");
                Dialog.show("Erreur de saisie", "Vous avez choisie une mot interdit !" + abc + " !", "Ok", null);
                ok2 = false;
                return ok2;
            } else {
                System.out.println("tout va bien");
            }
            //}

        }
        return ok2;
    }

    public Form getF() {
        return f;
    }

    public void setF(Form f) {
        this.f = f;
    }

    @Override
    public void scrollChanged(int scrollX, int scrollY, int oldscrollX, int oldscrollY) {
        System.out.println("YOU ARE SCROLLING NOW ! AWESOME !!");
    }

}
