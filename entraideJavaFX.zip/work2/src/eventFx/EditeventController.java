/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventFx;

import Entities.Event;
import Service.EventService;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class EditeventController implements Initializable {

    @FXML
    private AnchorPane homepage;
    @FXML
    private ImageView imageview;
   
    @FXML
    private JFXTextField name_event;
    @FXML
    private JFXTextField heure_debut;
    @FXML
    private JFXTextField desc_event;
    @FXML
    private DatePicker date_start_event;
    @FXML
    private DatePicker date_end_event;
    @FXML
    private JFXButton image_btn;
    @FXML
    private JFXButton save_btn;
    @FXML
    private JFXTextField heure_fin;
    @FXML
    private ImageView image_prev;
    String image ;
     private Event currentEvent;
     private Boolean okClicked = true;
     private Stage dialogStage;
    @FXML
    private Label error_input;
    @FXML
    private Label errorDatebut;
    @FXML
    private Label errorDateFin;
     

    public Event getCurrentEvent() {
        return currentEvent;
    }

    public void setCurrentEvent(Event currentEvent) {
        this.currentEvent = currentEvent;
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        String BI = "file:/C:/Users/lenovo/Documents/NetBeansProjects/work2/src/eventFx/LogoEsprit entr'aide.png";
        Image image = new Image(BI);
        imageview.setImage(image);
        imageview.fitHeightProperty();
        imageview.fitWidthProperty();
         imageview.setTranslateY(-120);
        // TODO
    }    

    @FXML
    private void GrandBTN(ActionEvent event) {
    }

    @FXML
    private void specialite(ActionEvent event) {
    }

    @FXML
    private void uploadImg(ActionEvent event) throws MalformedURLException {
        FileChooser fc = new FileChooser();
        System.out.println("clickedd");
        File selectedFile = fc.showOpenDialog(null);
        if (selectedFile != null) {

            image = selectedFile.toURI().toURL().toString();
            System.out.println(image);

            Image imageData = new Image(image);

            image_prev.setImage(imageData);

        } else {
            System.out.println("file doesn't exist");
        }
    }
    
     public void setEvent(Event evt) {
        setCurrentEvent(evt);
        name_event.setText(evt.getNom_evenement());
        Format formatter = new SimpleDateFormat("yyyy-MM-dd");
        date_start_event.setValue(LocalDate.parse(formatter.format(evt.getDate_debut())));     
        date_end_event.setValue(LocalDate.parse(formatter.format(evt.getDate_fin())));
 heure_debut.setText(evt.getHeure_debut());
  heure_fin.setText(evt.getHeure_fin());
        desc_event.setText(evt.getDescription());
         Image image = new Image(evt.getImage());
        image_prev.setImage(image);
       
    }

    @FXML
    private void addEvent(ActionEvent event) throws SQLException {
        EventService s = new EventService();
        Event evt = new Event();
        if(!checkEmpty()){
                return;
            }
        if(!checkDate()){
           return ;
        }
        
        currentEvent.setNom_evenement(name_event.getText());
        if (null != getImage()) {
            currentEvent.setImage(getImage());
        }

        Date date = java.sql.Date.valueOf(date_start_event.getValue());
        currentEvent.setDate_debut(date);
        currentEvent.setHeure_debut(heure_debut.getText());
        Date date_fin = java.sql.Date.valueOf(date_end_event.getValue());
        currentEvent.setDate_fin(date_fin);
        currentEvent.setHeure_fin(heure_fin.getText());
        currentEvent.setDescription(desc_event.getText());
        s.editEvent(currentEvent);
        okClicked = true;
        dialogStage.close();
    }

    public String getImage() {
        return image;
    }
    private void handleCancel() {
        dialogStage.close();
    }

    public Stage getDialogStage() {
        return dialogStage;
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public void setImage(String image) {
        this.image = image;
    }
    public boolean checkEmptyField(TextField element){
        
        if (element.getText() == null || element.getText().trim().isEmpty()) {
            return false; 
     // your code here
        }
        
        return true;
    }
    
    public boolean checkEmpty(){
        if(checkEmptyField(name_event) && checkEmptyField(heure_debut) && checkEmptyField(heure_fin)  && checkEmptyField(desc_event)){
            error_input.setVisible(false);
            return true;
        }else{
            error_input.setVisible(true);
            error_input.setText("saisir touts les champs");
            return false;
        }
    }
    
    
     public boolean isOkClicked() {
        return okClicked;
    }
    
    
    private boolean checkDate() {
        Date date_debut = java.sql.Date.valueOf(date_start_event.getValue());
        Date date_fin = java.sql.Date.valueOf(date_end_event.getValue());
        Date current = new Date();
        Boolean validate = true;
        if(current.compareTo(date_debut) > 0){
            errorDatebut.setVisible(true);
            errorDatebut.setText(" Date debut doit etre supérieure à la date actuelle");
            validate = false;
        }
        if(date_debut.compareTo(date_fin) > 0){
            errorDateFin.setVisible(true);
            errorDateFin.setText(" Date fin doit etre supérieure à la date debut");
            validate = false;
        }
        
        if(validate == true){
            errorDatebut.setVisible(false);            
            errorDateFin.setVisible(false);

        }
        
        return validate;
    }
}
