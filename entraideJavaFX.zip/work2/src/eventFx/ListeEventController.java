/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventFx;

import Entities.Club;
import Entities.Event;
import Service.EventService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class ListeEventController implements Initializable {

    @FXML
    private AnchorPane viewEvents;
    @FXML
    private ImageView imageview;
    @FXML
    private ListView<Event> listeView;
    ObservableList<Event> masterEvent = FXCollections.observableArrayList();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        EventService s = new  EventService();
        try {
            masterEvent = s.showEvent();
        } catch (SQLException ex) {
            Logger.getLogger(ListeEventController.class.getName()).log(Level.SEVERE, null, ex);
        }
        listeView.setItems(masterEvent);
         
        listeView.setCellFactory(new Callback<ListView<Event>, ListCell<Event>>(){
 
            @Override
            public ListCell<Event> call(ListView<Event> p) {
                 
                ListCell<Event> cell = new ListCell<Event>(){
                      private ImageView imageView = new ImageView();
                      
                    protected void updateItem(Event t, boolean bln) {
                      
                        super.updateItem(t, bln);
                        
                        if (t != null) {
                           
                             setText(" Nom evenement : "+t.getNom_evenement()+ " |  Date début :" + t.getDate_debut()+" | heure début : "+t.getHeure_debut()+" | Description  : "+t.getDescription());
                           if(t.getImage() != null){
                                imageView.setFitHeight(200);
                                imageView.setFitWidth(200);
                                Image image = new Image(t.getImage());                                
                                
                                imageView.setImage(image);
                                setGraphic(imageView);
                            } 
                        }
                    }
 
                };
                 
                return cell;
            }
        });
    }    

    @FXML
    private void GrandBTN(ActionEvent event) {
    }

    @FXML
    private void specialite(ActionEvent event) {
    }

    @FXML
    private void menuprincipal(ActionEvent event) throws IOException {
        AnchorPane paneADD = FXMLLoader.load(getClass().getResource("/ClubFX/Layout.fxml"));
        viewEvents.getChildren().setAll(paneADD);
    }
    
}
