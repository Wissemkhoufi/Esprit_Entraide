/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventFx;

import Entities.Event;
import Service.EventService;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class VieweventController implements Initializable {

  
    @FXML
    private ImageView imageview;
    @FXML
    private JFXButton delete_event;
    @FXML
    private TableView<Event> table_event;
    @FXML
    private TableColumn<?, ?> nom_evenement;
    @FXML
    private TableColumn<?, ?> description;
    @FXML
    private TableColumn<?, ?> date_debut;
    @FXML
    private TableColumn<?, ?> heure_debut;
    @FXML
    private TableColumn<?, ?> date_fin;
    @FXML
    private TableColumn<?, ?> heure_fin;
    @FXML
    private JFXButton update_event;
    @FXML
    private JFXButton menupricipal;
    @FXML
    private JFXTextField filter_text;
    
    ObservableList<Event> listEvent = FXCollections.observableArrayList();   
    ObservableList<Event> masterEvent = FXCollections.observableArrayList();
    @FXML
    private AnchorPane viewEvents;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String BI = "file:/C:/Users/lenovo/Documents/NetBeansProjects/work2/src/eventFx/LogoEsprit entr'aide.png";
        Image image = new Image(BI);
        imageview.setImage(image);
        imageview.fitHeightProperty();
        imageview.fitWidthProperty();
         imageview.setTranslateY(-120);
        afficher();
        
        filter_text.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable,
                    String oldValue, String newValue) {

                updateFilteredData();
            }
        });
        // TODO
    } 

 private void updateFilteredData() {
        listEvent.clear();  

        for (Event p : masterEvent) { 
            if (matchesFilter(p)) { 
                listEvent.add(p);   
            }
        }

        // Must re-sort table after items changed
        reapplyTableSortOrder();
    }
 
 private boolean matchesFilter(Event event) {
        String filterString = filter_text.getText();
        if (filterString == null || filterString.isEmpty()) {
            // No filter --> Add all.
            return true;
        }

        String lowerCaseFilterString = filterString.toLowerCase();
        System.out.print(lowerCaseFilterString);
        if (event.getNom_evenement().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        } else if (event.getDescription().toLowerCase().indexOf(lowerCaseFilterString) != -1) {
            return true;
        }

        return false; // Does not match
    }
 
 private void reapplyTableSortOrder() {
        
        table_event.getSortOrder().clear(); 
        table_event.setItems(listEvent); 
       // ArrayList<TableColumn<Event, ?>> sortOrder = new ArrayList<>(table_event.getSortOrder());
    }


    @FXML
    private void GrandBTN(ActionEvent event) {
    }

    @FXML
    private void specialite(ActionEvent event) {
    }

    @FXML
    private void AjoutBtn(ActionEvent event) throws IOException {
         AnchorPane paneADD = FXMLLoader.load(getClass().getResource("Addevent.fxml"));
        viewEvents.getChildren().setAll(paneADD);
    }

    @FXML
    private void affichbtn(ActionEvent event) {
    }

    @FXML
    private void menu_principal(ActionEvent event) throws IOException {
        AnchorPane paneADD = FXMLLoader.load(getClass().getResource("/ClubFx/Layout.fxml"));
        viewEvents.getChildren().setAll(paneADD);
    }


    @FXML
    private void deleteEvent(ActionEvent event) throws SQLException {
        if (!table_event.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Supprimer evenement");
            alert.setHeaderText("Voulez vous vraiment supprimer ? : " + table_event.getSelectionModel().getSelectedItem().getId_ev() + " ?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                EventService s = new EventService();
                s.deleteEvent(table_event.getSelectionModel().getSelectedItem().getId_ev());
                afficher();

            }
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Erreur");
            alert.setHeaderText("Veuillez selectionner une station !");
            Optional<ButtonType> result = alert.showAndWait();
        }
    }
    
    
    public void afficher() {
         
        try {
            EventService s = new EventService();
            masterEvent = s.showEvent();
            nom_evenement.setCellValueFactory(new PropertyValueFactory<>("nom_evenement"));
            date_debut.setCellValueFactory(new PropertyValueFactory<>("date_debut"));
             heure_debut.setCellValueFactory(new PropertyValueFactory<>("heure_debut"));
            date_fin.setCellValueFactory(new PropertyValueFactory<>("date_fin"));
            heure_fin.setCellValueFactory(new PropertyValueFactory<>("heure_fin"));
            description.setCellValueFactory(new PropertyValueFactory<>("description"));

            table_event.setItems(null);
            table_event.setItems(masterEvent);
        } catch (SQLException ex) {

            Logger.getLogger(VieweventController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void updateEvent(ActionEvent event) {
        Event selectedEvent = table_event.getSelectionModel().getSelectedItem();
        if (selectedEvent != null) {
            //si un ele est selectionnr afficher la modal
            boolean okClicked = showEventEditDialog(selectedEvent);
            if (okClicked) {
                afficher();
            }

        }
    } 
   
    
    public boolean showEventEditDialog(Event evt) {
        //si un ele est selectionnr afficher la modal
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader(getClass().getResource("editevent.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit Evenement");
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.initOwner(viewEvents.getScene().getWindow());
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Set the club into the controller.
            EditeventController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setEvent(evt);

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();

            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    } 
}
