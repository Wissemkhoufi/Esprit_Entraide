/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventFx;

import Entities.Event;
import Service.EventService;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import org.controlsfx.control.Notifications;
import service.PersonneService;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class AddeventController implements Initializable {

    @FXML
    private AnchorPane homepage;
    @FXML
    private ImageView imageview;
    @FXML
    private JFXTextField name_event;
    @FXML
    private JFXTextField heure_debut;
    @FXML
    private JFXTextField heure_fin;
    @FXML
    private JFXButton image_btn;
    @FXML
    private JFXTextField desc_event;
    @FXML
    private JFXButton save_btn;
    @FXML
    private DatePicker date_start_event;
    @FXML
    private DatePicker date_end_event;
     String imageFile;
    @FXML
    private ImageView image_prev;
    @FXML
    private Label error_input;
    @FXML
    private Label errorDateFin;
    @FXML
    private Label errorDateDebut;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
         String BI = "file:/C:/Users/lenovo/Documents/NetBeansProjects/work2/src/eventFx/LogoEsprit entr'aide.png";
        Image image = new Image(BI);
        imageview.setImage(image);
        imageview.fitHeightProperty();
        imageview.fitWidthProperty();
         imageview.setTranslateY(-120);
        
    }    

    @FXML
    private void GrandBTN(ActionEvent event) {
    }

    @FXML
    private void specialite(ActionEvent event) {
    }

    @FXML
    private void AjoutBtn(ActionEvent event) {
    }

    @FXML
    private void affichbtn(ActionEvent event) throws IOException {
        AnchorPane paneADD = FXMLLoader.load(getClass().getResource("viewevent.fxml"));
        homepage.getChildren().setAll(paneADD);
    }

    @FXML
    private void uploadImg(ActionEvent event) throws MalformedURLException {
        FileChooser fc = new FileChooser();
        System.out.println("clickedd");
        File selectedFile = fc.showOpenDialog(null);
        if (selectedFile != null) {

            imageFile = selectedFile.toURI().toURL().toString();
            System.out.println(imageFile);

            Image image = new Image(imageFile);

            image_prev.setImage(image);

        } else {
            System.out.println("file doesn't exist");
        }
    }

    @FXML
    private void addEvent(ActionEvent event) throws SQLException {
        EventService s = new EventService();        
        PersonneService ps = new PersonneService();
        if(!checkEmpty()){
            return;
        }
        if(!checkDate()){
           return ;
        }
        Event evt = new Event();
        evt.setNom_evenement(name_event.getText());        
        evt.setImage(imageFile);
        Date date = java.sql.Date.valueOf(date_start_event.getValue());
        evt.setDate_debut(date);
        evt.setHeure_debut(heure_debut.getText());
        Date date_fin = java.sql.Date.valueOf(date_end_event.getValue());
        evt.setDate_fin(date_fin);
        evt.setHeure_fin(heure_fin.getText());
        evt.setDescription(desc_event.getText());
        s.addEvent(evt);
         ps.notifyPersonnes(evt);
        
         Notifications notificationBuilder =Notifications.create() 
                  .title("evenement ajouté avec succés")
                  .hideAfter(javafx.util.Duration.seconds(3))
                  .darkStyle()
                  .position(Pos.CENTER)
                  ;
         notificationBuilder.showInformation();
    }
    
     public boolean checkEmptyField(TextField element){
        
        if (element.getText() == null || element.getText().trim().isEmpty()) {
            return false; 
     
        }
        
        return true;
    }
    
     public boolean checkEmpty(){
        if(checkEmptyField(name_event) && checkEmptyField(heure_debut) && checkEmptyField(heure_fin) && checkEmptyField(desc_event) ){
            error_input.setVisible(false);
            
            return true;
        }else{
            error_input.setVisible(true);
            error_input.setText("saisir touts les champs");
            return false;
        }
    }
      private boolean checkDate() {
        Date date_debut = java.sql.Date.valueOf(date_start_event.getValue());
        Date date_fin = java.sql.Date.valueOf(date_end_event.getValue());
        Date current = new Date();
        Boolean validate = true;
        if(current.compareTo(date_debut) > 0){
            errorDateDebut.setVisible(true);
            errorDateDebut.setText(" Date debut doit etre supérieure à la date actuelle");
            validate = false;
        }
        if(date_debut.compareTo(date_fin) > 0){
            errorDateFin.setVisible(true);
            errorDateFin.setText(" Date fin doit etre supérieure à la date debut");
            validate = false;
        }
        
        if(validate == true){
            errorDateDebut.setVisible(false);            
            errorDateFin.setVisible(false);

        }
        
        return validate;
    }

    @FXML
    private void listeeven(ActionEvent event) throws IOException {
        AnchorPane paneADD = FXMLLoader.load(getClass().getResource("listeEvent.fxml"));
        homepage.getChildren().setAll(paneADD);
    }
}
