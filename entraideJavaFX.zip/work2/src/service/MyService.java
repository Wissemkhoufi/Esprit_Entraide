/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entities.Club;
import Technique.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author lenovo
 */
public class MyService {
    Connection connection;
    PreparedStatement preparedStatement;
   
    public void addClub(Club c ) throws SQLException{
       String requete = "INSERT INTO `club` (nom_club, image, conseiller_pedagogique,description) VALUES ('"+c.getNom_club()+"','"+c.getImage()+"','"+c.getConseiller_pedagogique()+"','"+c.getDescription()+"')";
        try {
            Statement st=DataSource.getInstance().getConn().createStatement();
            st.executeUpdate(requete);
           System.out.println("Club ajouter avec succées");
        }
        catch (SQLException ex) {
           System.out.println("probleme de connexion au niveau addClub "+ex.getMessage());
       }
        
        /*String requete="INSERT INTO `commodite`(`nom`, `commodite_image`,`type`, `adresse`, `description`, `note`) VALUES (?,?,?,?,?,?)";
        /*try {*/
           /* preparedStatement = connection.prepareStatement(requete);
          
            preparedStatement.setString(1, c.getNom());
            preparedStatement.setString(2, c.getCommodite_image());
            preparedStatement.setString(3, c.getType());
            preparedStatement.setString(4, c.getAdresse());
            preparedStatement.setString(5, c.getDescription());
            preparedStatement.setInt(6, c.getNote());
            
            preparedStatement.executeUpdate();
       /* } catch (SQLException ex) {
            ex.printStackTrace();
        }*/
    }
    
    
    public void editClub(Club c ) throws SQLException{
       String requete = "UPDATE `club` SET nom_club = '"+c.getNom_club()+"', description='"+c.getDescription()+"',image='"+c.getImage()+"' , conseiller_pedagogique = '"+c.getConseiller_pedagogique()+"' WHERE id_club = "+c.getId_club();
        try {
            Statement st=DataSource.getInstance().getConn().createStatement();
            st.executeUpdate(requete);
           System.out.println("Club editee avec succées");
        }
        catch (SQLException ex) {
           System.out.println("probleme de connexion au niveau addClub "+ex.getMessage());
       }
        
        /*String requete="INSERT INTO `commodite`(`nom`, `commodite_image`,`type`, `adresse`, `description`, `note`) VALUES (?,?,?,?,?,?)";
        /*try {*/
           /* preparedStatement = connection.prepareStatement(requete);
          
            preparedStatement.setString(1, c.getNom());
            preparedStatement.setString(2, c.getCommodite_image());
            preparedStatement.setString(3, c.getType());
            preparedStatement.setString(4, c.getAdresse());
            preparedStatement.setString(5, c.getDescription());
            preparedStatement.setInt(6, c.getNote());
            
            preparedStatement.executeUpdate();
       /* } catch (SQLException ex) {
            ex.printStackTrace();
        }*/
    }

    public ObservableList<Club> showclub() throws  SQLException
 {     
       ObservableList<Club> myList = FXCollections.observableArrayList();
       String requete = "select id_club, image, nom_club,conseiller_pedagogique,date_creation,description from club ";
        try {
            Statement st=DataSource.getInstance().getConn().createStatement();
            ResultSet rs =st.executeQuery(requete);
        while(rs.next()){
             Club c =new Club();
             
             c.id_club=rs.getInt(1);
             c.image=rs.getString(2);
             c.nom_club=rs.getString(3);             
             
             c.conseiller_pedagogique=rs.getString(4);
             c.date_creation=rs.getDate(5);
             c.description=rs.getString(6);
             
             myList.add(c);
             
         }}
        catch (SQLException ex) {
           System.out.println("probleme de connexion"+ex.getMessage());
       }
        return myList;
   
}
    public void deleteClub (int x) throws SQLException{
        String req ="DELETE FROM club WHERE id_club = ?";
        PreparedStatement pst = DataSource.getInstance().getConn().prepareStatement(req);
        pst.setInt(1, x);
        pst.executeUpdate();
    
    }
     
    public MyService() {
        connection = DataSource.getInstance().getConn();
    }

    
    
}


