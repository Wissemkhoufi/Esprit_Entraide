/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import Entities.Event;
import Technique.DataSource;
import Technique.EmailService;
import entities.Personne;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author lenovo
 */
public class PersonneService {
    
     Connection connection;
    PreparedStatement preparedStatement;

    public ObservableList<Personne> allPersonnes() throws SQLException {
        ObservableList<Personne> myList = FXCollections.observableArrayList();
        String requete = "select id, email from personne ";
        try {
            Statement st = DataSource.getInstance().getConn().createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                Personne p = new Personne();

                p.setId(rs.getInt(1));
                p.setEmail(rs.getString(2));

                myList.add(p);

            }
        } catch (SQLException ex) {
            System.out.println("probleme de connexion" + ex.getMessage());
        }
        return myList;

    }
    
    public void notifyPersonnes(Event event) throws SQLException{
        EmailService es = new EmailService();
        String text = new String();
        text+="Bienvenu a esprit\n";          
        text+=event.getNom_evenement()+"\n";        
      
        text+=event.getDate_debut()+"\n";   
        text+=event.getHeure_debut()+"\n";
                text+=event.getDate_fin()+"\n"; 
                text+=event.getHeure_fin()+"\n";
                text+=event.getDescription()+"\n";



        ObservableList<Personne> personnes = allPersonnes();
        for (Personne personne : personnes) {
            es.sendEmail(personne.getEmail(), event.getNom_evenement(),  text);
        }
        
    }

    public PersonneService() {
        connection = DataSource.getInstance().getConn();
    }
}
