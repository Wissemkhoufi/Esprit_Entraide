/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entities.Event;
import Technique.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author lenovo
 */
public class EventService {
    Connection connection;
    PreparedStatement preparedStatement;
   
    public void addEvent(Event c ) throws SQLException{
       String requete = "INSERT INTO `evenement` (nom_evenement ,image ,date_debut,heure_debut ,date_fin,heure_fin ,description) VALUES "
               + "('"+c.getNom_evenement()+"','"+c.getImage()+"','"+c.getDate_debut()+"','"+c.getHeure_debut()+"','"+c.getDate_fin()+"','"+c.getHeure_fin()+"','"+c.getDescription()+"')";
        try {
            Statement st=DataSource.getInstance().getConn().createStatement();
            st.executeUpdate(requete);
           System.out.println("Event ajouter avec succées");
        }
        catch (SQLException ex) {
           System.out.println("probleme de connexion au niveau addEvent "+ex.getMessage());
       }
        
        /*String requete="INSERT INTO `commodite`(`nom`, `commodite_image`,`type`, `adresse`, `description`, `note`) VALUES (?,?,?,?,?,?)";
        /*try {*/
           /* preparedStatement = connection.prepareStatement(requete);
          
            preparedStatement.setString(1, c.getNom());
            preparedStatement.setString(2, c.getCommodite_image());
            preparedStatement.setString(3, c.getType());
            preparedStatement.setString(4, c.getAdresse());
            preparedStatement.setString(5, c.getDescription());
            preparedStatement.setInt(6, c.getNote());
            
            preparedStatement.executeUpdate();
       /* } catch (SQLException ex) {
            ex.printStackTrace();
        }*/
    }
    
    
    public void editEvent(Event c ) throws SQLException{
       String requete = "UPDATE `evenement` SET nom_evenement = '"+c.getNom_evenement()+"', date_debut='"+c.getDate_debut()+"',heure_debut='"+c.getHeure_debut()+"',image='"+c.getImage()+"' , date_fin = '"+c.getDate_fin()+"',heure_fin='"+c.getHeure_fin()+"', description = '"+c.getDescription()+"' WHERE id_ev = "+c.getId_ev();
        try {
            Statement st=DataSource.getInstance().getConn().createStatement();
            st.executeUpdate(requete);
           System.out.println("Event editee avec succées");
        }
        catch (SQLException ex) {
           System.out.println("probleme de connexion au niveau addEvent "+ex.getMessage());
       }
        
        /*String requete="INSERT INTO `commodite`(`nom`, `commodite_image`,`type`, `adresse`, `description`, `note`) VALUES (?,?,?,?,?,?)";
        /*try {*/
           /* preparedStatement = connection.prepareStatement(requete);
          
            preparedStatement.setString(1, c.getNom());
            preparedStatement.setString(2, c.getCommodite_image());
            preparedStatement.setString(3, c.getType());
            preparedStatement.setString(4, c.getAdresse());
            preparedStatement.setString(5, c.getDescription());
            preparedStatement.setInt(6, c.getNote());
            
            preparedStatement.executeUpdate();
       /* } catch (SQLException ex) {
            ex.printStackTrace();
        }*/
    }

    public ObservableList<Event> showEvent() throws  SQLException
 {     
       ObservableList<Event> myList = FXCollections.observableArrayList();
       String requete = "select id_ev, image, nom_evenement, date_debut, heure_debut , date_fin,heure_fin, description from evenement ";
        try {
            Statement st=DataSource.getInstance().getConn().createStatement();
            ResultSet rs =st.executeQuery(requete);
        while(rs.next()){
             Event ev =new Event();
             
             ev.setId_ev(rs.getInt(1));
             ev.setImage(rs.getString(2));
             ev.setNom_evenement(rs.getString(3));             
             
             ev.setDate_debut(rs.getDate(4));
             ev.setHeure_debut(rs.getString(5));             
             ev.setDate_fin(rs.getDate(6));
             ev.setHeure_fin(rs.getString(7));
             ev.setDescription(rs.getString(8));
             
             myList.add(ev);
             
         }}
        catch (SQLException ex) {
           System.out.println("probleme de connexion"+ex.getMessage());
       }
        return myList;
   
}
    public void deleteEvent (int x) throws SQLException{
        String req ="DELETE FROM evenement WHERE id_ev = ?";
        PreparedStatement pst = DataSource.getInstance().getConn().prepareStatement(req);
        pst.setInt(1, x);
        pst.executeUpdate();
    
    }
     
    public EventService() {
        connection = DataSource.getInstance().getConn();
    }

    
    
}


