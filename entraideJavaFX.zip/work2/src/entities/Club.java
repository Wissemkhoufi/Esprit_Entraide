/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class Club {
    public int id_club;
    public String nom_club;
    public String conseiller_pedagogique;
    public Date date_creation;
    public String description;
    public String image;
    public static Club instance;

    public Club(
            int id_club, 
            String nom_club,
            String conseiller_pedagogique, 
            Date date_creation, 
            String description, 
            String description_detailler,
            String img
    ) {
        
        this.id_club = id_club;
        this.nom_club = nom_club;
        this.conseiller_pedagogique = conseiller_pedagogique;
        this.date_creation = date_creation;
        this.description = description;
        this.image = img;
      
    }

    public Club() {
        
    }

    @Override
    public String toString() {
        return "Club{" + "id_club=" + id_club + ", nom_club=" + nom_club + ", conseiller_pedagogique=" + conseiller_pedagogique + ", date_creation=" + date_creation + ", description=" + description +  '}';
    }

    public int getId_club() {
        return id_club;
    }

    public void setId_club(int id_club) {
        this.id_club = id_club;
    }

    public String getNom_club() {
        return nom_club;
    }

    public void setNom_club(String nom_club) {
        this.nom_club = nom_club;
    }

    public String getConseiller_pedagogique() {
        return conseiller_pedagogique;
    }

    public void setConseiller_pedagogique(String conseiller_pedagogique) {
        this.conseiller_pedagogique = conseiller_pedagogique;
    }

    public Date getDate_creation() {
        return date_creation;
    }

    public void setDate_creation(Date date_creation) {
        this.date_creation = date_creation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

  
    
    
    

   public static Club getInstance(){
        if (instance==null){
            instance = new Club();
        }
        return instance;
    }    

    
 
}
