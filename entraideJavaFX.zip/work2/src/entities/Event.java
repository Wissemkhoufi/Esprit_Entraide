/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import Entities.*;
import java.util.Date;

/**
 *
 * @author ASUS
 */
public class Event {

    public int id_ev;

    public String nom_evenement;

    public String image;

    public Date date_debut;
    public String heure_debut;

    public Date date_fin;
    public String heure_fin;
    public String description;

    public Event() {

    }

    public Event(int id_ev, String nom_evenement, String image, Date date_debut, String heure_debut, Date date_fin, String heure_fin, String description) {
        this.id_ev = id_ev;
        this.nom_evenement = nom_evenement;
        this.image = image;
        this.date_debut = date_debut;
        this.heure_debut = heure_debut;
        this.date_fin = date_fin;
        this.heure_fin = heure_fin;
        this.description = description;
    }

    public String getHeure_debut() {
        return heure_debut;
    }

    public void setHeure_debut(String heure_debut) {
        this.heure_debut = heure_debut;
    }

    public String getHeure_fin() {
        return heure_fin;
    }

    public void setHeure_fin(String heure_fin) {
        this.heure_fin = heure_fin;
    }
    
      

    public int getId_ev() {
        return id_ev;
    }

    public void setId_ev(int id_ev) {
        this.id_ev = id_ev;
    }

    public String getNom_evenement() {
        return nom_evenement;
    }

    public void setNom_evenement(String nom_evenement) {
        this.nom_evenement = nom_evenement;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Date getDate_debut() {
        return date_debut;
    }

    public void setDate_debut(Date date_debut) {
        this.date_debut = date_debut;
    }

    public Date getDate_fin() {
        return date_fin;
    }

    public void setDate_fin(Date date_fin) {
        this.date_fin = date_fin;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Event{" + "id_ev=" + id_ev + ", nom_evenement=" + nom_evenement + ", image=" + image + ", date_debut=" + date_debut + ", heure_debut=" + heure_debut + ", date_fin=" + date_fin + ", heure_fin=" + heure_fin + ", description=" + description + '}';
    }

   
    
    

  

    

}
