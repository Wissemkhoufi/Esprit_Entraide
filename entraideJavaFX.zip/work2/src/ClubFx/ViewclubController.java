/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClubFx;

import Entities.Club;
import Service.MyService;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class ViewclubController implements Initializable {

    @FXML
    private AnchorPane homepage;
    @FXML
    private ImageView imageview;
    @FXML
    private TableView<Club> tableview;
    @FXML
    private TableColumn<?, ?> nom_club;
    @FXML
    private TableColumn<?, ?> conseiller_pedagogique;
    @FXML
    private TableColumn<?, ?> date_creation;
    @FXML
    private TableColumn<?, ?> description;
    @FXML
    private JFXButton edit_club_btn;
    @FXML
    private JFXButton revientajout;
    @FXML
    private JFXButton delete_club_btn;
    @FXML
    private ChoiceBox<String> comboRech;
    @FXML
    private TextField recherchertxt;
     ObservableList<String> comboList = FXCollections.observableArrayList("nom club","Conseiller pedagogique","description");

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         String BI = "file:/C:/Users/lenovo/Documents/NetBeansProjects/work2/src/ClubFx/LogoEsprit entr'aide.png";
        Image image = new Image(BI);
        imageview.setImage(image);
        imageview.fitHeightProperty();
        imageview.fitWidthProperty();
         imageview.setTranslateY(-120);
        
        afficher();
        comboRech.setItems(comboList);
      recherchertxt.textProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                try {
                    filtrerTeamList((String) oldValue, (String) newValue);
                } catch (SQLException ex) {
                    Logger.getLogger(ViewclubController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });
        
    }    

    @FXML
    private void GrandBTN(ActionEvent event) {
    }

    @FXML
    private void specialite(ActionEvent event) {
    }

    @FXML
    private void AjoutBtn(ActionEvent event) throws IOException {
         AnchorPane paneADD = FXMLLoader.load(getClass().getResource("Addclub.fxml"));
        homepage.getChildren().setAll(paneADD);
    }

    @FXML
    private void affichbtn(ActionEvent event) {
    }

    @FXML
    private void editClub(ActionEvent event) {
        Club selectedClub = tableview.getSelectionModel().getSelectedItem();
        if (selectedClub != null) {
            //si un ele est selectionnr afficher la modal
            boolean okClicked = showClubEditDialog(selectedClub);
            if (okClicked) {
                afficher();
            }

        }
    }
    
    public boolean showClubEditDialog(Club club) {
        //si un ele est selectionnr afficher la modal
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Editclub.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit Person");
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.initOwner(homepage.getScene().getWindow());
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Set the club into the controller.
            EditclubController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setClub(club);

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();

            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }


    @FXML
    private void revientajout(ActionEvent event) throws IOException {
        AnchorPane paneADD = FXMLLoader.load(getClass().getResource("Layout.fxml"));
        homepage.getChildren().setAll(paneADD);
        
    }

    @FXML
    private void deleteClub(ActionEvent event) throws SQLException {
        if (!tableview.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Supprimer club");
            alert.setHeaderText("Voulez vous vraiment supprimer ? : " + tableview.getSelectionModel().getSelectedItem().getId_club() + " ?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                MyService s = new MyService();
                s.deleteClub(tableview.getSelectionModel().getSelectedItem().getId_club());
                afficher();

            }
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Erreur");
            alert.setHeaderText("Veuillez selectionner une station !");
            Optional<ButtonType> result = alert.showAndWait();
        }
    }
    
    public void afficher() {

        try {
            MyService s = new MyService();

            nom_club.setCellValueFactory(new PropertyValueFactory<>("nom_club"));
            conseiller_pedagogique.setCellValueFactory(new PropertyValueFactory<>("conseiller_pedagogique"));
            date_creation.setCellValueFactory(new PropertyValueFactory<>("date_creation"));
            description.setCellValueFactory(new PropertyValueFactory<>("description"));

            tableview.setItems(null);
            tableview.setItems(s.showclub());
        } catch (SQLException ex) {

            Logger.getLogger(ViewclubController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    void filtrerTeamList(String oldValue, String newValue) throws SQLException {
        String choix = (String) comboRech.getValue();
        MyService st = new MyService();
        if (choix.equals("nom club")) {
            ObservableList<Club> filteredList = FXCollections.observableArrayList();
            if (recherchertxt.getText() == null || newValue == null) {
                tableview.setItems(st.showclub());
            } else {
                tableview.setItems(st.showclub());
                newValue = newValue.toUpperCase();

                for (Club club : tableview.getItems()) {

                    String filterClubname = club.getNom_club();

                    if (filterClubname.toUpperCase().contains(newValue)) {
                        filteredList.add(club);

                    }

                }
                tableview.setItems(filteredList);

            }

        } else if (choix.equals("Conseiller pedagogique")) {

            ObservableList<Club> filteredList = FXCollections.observableArrayList();
            if (recherchertxt.getText()== null || newValue == null) {
                tableview.setItems(st.showclub());
            } else {
                tableview.setItems(st.showclub());
                newValue = newValue.toUpperCase();

                for (Club club : tableview.getItems()) {

                    String filterClubname = club.getConseiller_pedagogique();

                    if (filterClubname.toUpperCase().contains(newValue)) {
                        filteredList.add(club);

                    }

                }
                tableview.setItems(filteredList);

            }

        } else {
            
            ObservableList<Club> filteredList = FXCollections.observableArrayList();
            if (recherchertxt.getText()== null || newValue == null) {
                tableview.setItems(st.showclub());
            } else {
                tableview.setItems(st.showclub());
              

                newValue = newValue.toUpperCase();

                for (Club club : tableview.getItems()) {
                   
                    String filterTeamName = club.getDescription();

                    if (filterTeamName.toUpperCase().contains(newValue)) {
                        filteredList.add(club);

                    }

                }
                tableview.setItems(filteredList);

            }
        }
    }

    @FXML
    private void listeclub(ActionEvent event) throws IOException {
        AnchorPane paneADD = FXMLLoader.load(getClass().getResource("listeclub.fxml"));
        homepage.getChildren().setAll(paneADD);
    }

}
