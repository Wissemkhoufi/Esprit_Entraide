/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClubFx;

import Entities.Club;
import Service.MyService;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class AddclubController implements Initializable {

    @FXML
    private AnchorPane homepage;
    @FXML
    private ImageView imageview;
    @FXML
    private JFXTextField nom_club;
    @FXML
    private JFXTextField conseiller_pedagogique;
    @FXML
    private JFXTextField description;
    @FXML
    private JFXButton image_btn;
    @FXML
    private ImageView imagrPrev;
    @FXML
    private JFXButton addClub;
String imageFile;
    @FXML
    private Label error_input;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         String BI = "file:/C:/Users/lenovo/Documents/NetBeansProjects/work2/src/ClubFx/LogoEsprit entr'aide.png";
        Image image = new Image(BI);
        imageview.setImage(image);
        imageview.fitHeightProperty();
        imageview.fitWidthProperty();
         imageview.setTranslateY(-120);
        
    }    

    @FXML
    private void GrandBTN(ActionEvent event) {
    }

    @FXML
    private void specialite(ActionEvent event) {
    }

    @FXML
    private void AjoutBtn(ActionEvent event) {
    }

    @FXML
    private void affichbtn(ActionEvent event) throws IOException {
        AnchorPane paneADD = FXMLLoader.load(getClass().getResource("viewclub.fxml"));
        homepage.getChildren().setAll(paneADD);
    }

    @FXML
    private void addim(ActionEvent event) throws MalformedURLException {
         FileChooser fc = new FileChooser();
        System.out.println("clickedd");
        File selectedFile = fc.showOpenDialog(null);
        if (selectedFile != null) {

            imageFile = selectedFile.toURI().toURL().toString();
            System.out.println(imageFile);

            Image image = new Image(imageFile);

            imagrPrev.setImage(image);

        } else {
            System.out.println("file doesn't exist");
        }
    }

    @FXML
    private void addClub(ActionEvent event) throws SQLException  {
         if(!checkEmpty()){
            return;
        }
        MyService s = new MyService();
        Club club = new Club();
        club.setNom_club(nom_club.getText());        
        club.setImage(imageFile);
        club.setConseiller_pedagogique(conseiller_pedagogique.getText());
        club.setDescription(description.getText());

        s.addClub(club);
        
        Notifications notificationBuilder =Notifications.create() 
                  .title("club ajouté avec succés")
                  .hideAfter(javafx.util.Duration.seconds(3))
                  .darkStyle()
                  .position(Pos.CENTER)
                  ;
         notificationBuilder.showInformation();

    }
    public boolean checkEmptyField(TextField element){
        
        if (element.getText() == null || element.getText().trim().isEmpty()) {
            return false; 
     // your code here
        }
        
        return true;
    }
    
    public boolean checkEmpty(){
        if(checkEmptyField(nom_club) && checkEmptyField(description) && checkEmptyField(conseiller_pedagogique) ){
            error_input.setVisible(false);
            return true;
        }else{
            error_input.setVisible(true);
            error_input.setText("saisir touts les champs");
            return false;
        }
    }
   
}

 


