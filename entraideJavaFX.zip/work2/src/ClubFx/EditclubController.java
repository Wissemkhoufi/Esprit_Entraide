/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClubFx;

import Entities.Club;
import Service.MyService;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class EditclubController implements Initializable {

    @FXML
    private AnchorPane homepage;
    @FXML
    private ImageView imageview;
    
    @FXML
    private JFXTextField nom_club;
    @FXML
    private JFXTextField conseil_peda;
    @FXML
    private JFXTextField description;
    @FXML
    private ImageView image_prev;
String image;
   private Club currentClub;
    private Stage dialogStage;
     private Boolean okClicked= true;
    @FXML
    private Label error_input;
    @FXML
    private JFXButton edit_img_btn;
    @FXML
    private JFXButton edit_club_button;
/**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         String BI = "file:/C:/Users/lenovo/Documents/NetBeansProjects/work2/src/ClubFx/LogoEsprit entr'aide.png";
        Image image = new Image(BI);
        imageview.setImage(image);
        imageview.fitHeightProperty();
        imageview.fitWidthProperty();
         imageview.setTranslateY(-120);
        
        // TODO
    }    

    @FXML
    private void GrandBTN(ActionEvent event) {
    }

    @FXML
    private void specialite(ActionEvent event) {
    }

    @FXML
    private void editImg(ActionEvent event) throws MalformedURLException {
          FileChooser fc = new FileChooser();
        System.out.println("clickedd");
        File selectedFile = fc.showOpenDialog(null);
        if (selectedFile != null) {

            image = selectedFile.toURI().toURL().toString();
            System.out.println(image);

            Image imageData = new Image(image);

            image_prev.setImage(imageData);

        } else {
            System.out.println("file doesn't exist");
        }
    }
    
     public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

     public boolean isOkClicked() {
        return okClicked;
    }
   
    public void setClub(Club club) {
        
        setCurrentClub(club);
        nom_club.setText(club.getNom_club());
        conseil_peda.setText(club.getConseiller_pedagogique());
        description.setText(club.getDescription());
         Image image = new Image(club.getImage());
        image_prev.setImage(image);
       
    }

    public Club getCurrentClub() {
        return currentClub;
    }

    public void setCurrentClub(Club currentClub) {
        this.currentClub = currentClub;
    }
    

    @FXML
    private void handleOk(ActionEvent event) throws SQLException {
         if(!checkEmpty()){
                return;
            }
            currentClub.setNom_club(nom_club.getText());
            currentClub.setConseiller_pedagogique(conseil_peda.getText());
            if(null != getImage()){
                currentClub.setImage(getImage());
            }
            
            currentClub.setDescription(description.getText());
            MyService s = new MyService();
           
            s.editClub(currentClub);
            okClicked = true;
            dialogStage.close();
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    
     public boolean checkEmptyField(TextField element){
        
        if (element.getText() == null || element.getText().trim().isEmpty()) {
            return false; 
     // your code here
        }
        
        return true;
    }
    
    public boolean checkEmpty(){
        if(checkEmptyField(nom_club) && checkEmptyField(description) && checkEmptyField(conseil_peda) ){
            error_input.setVisible(false);
            return true;
        }else{
            error_input.setVisible(true);
            error_input.setText("saisir tout les champs");
            return false;
        }
    }

}
