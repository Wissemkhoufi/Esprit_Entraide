/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClubFx;

import Entities.Club;
import Entities.Event;
import Service.EventService;
import Service.MyService;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class ListeclubController implements Initializable {

    @FXML
    private AnchorPane viewEvents;
    @FXML
    private ImageView imageview;
    @FXML
    private ListView<Club> listView;
ObservableList<Club> masterEvent = FXCollections.observableArrayList();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         String BI = "file:/C:/Users/lenovo/Documents/NetBeansProjects/work2/src/ClubFx/LogoEsprit entr'aide.png";
        Image image = new Image(BI);
        imageview.setImage(image);
        imageview.fitHeightProperty();
        imageview.fitWidthProperty();
         imageview.setTranslateY(-120);
        
        MyService s = new  MyService();
        try {
            masterEvent = s.showclub();
        } catch (SQLException ex) {
            Logger.getLogger(ListeclubController.class.getName()).log(Level.SEVERE, null, ex);
        }
        listView.setItems(masterEvent);
         
        listView.setCellFactory(new Callback<ListView<Club>, ListCell<Club>>(){
 
            @Override
            public ListCell<Club> call(ListView<Club> p) {
                 
                ListCell<Club> cell = new ListCell<Club>(){
                      private ImageView imageView = new ImageView();
                      
                    protected void updateItem(Club t, boolean bln) {
                      
                        super.updateItem(t, bln);
                        
                        if (t != null) {
                           
                             setText(" Nom club : "+t.getNom_club()+ " | Conseiller pedagogique : :" + t.getConseiller_pedagogique()+" | Date creation : "+t.getDate_creation()+" | Description  : "+t.getDescription());
                            if(t.getImage() != null){
                                imageView.setFitHeight(200);
                                imageView.setFitWidth(200);
                                Image image = new Image(t.getImage());                                
                                
                                imageView.setImage(image);
                                setGraphic(imageView);
                            }
                        }
                    }
 
                };
                 
                return cell;
            }
        });
        // TODO
    }    

    @FXML
    private void GrandBTN(ActionEvent event) {
    }

    @FXML
    private void specialite(ActionEvent event) {
    }

    @FXML
    private void retour(ActionEvent event) throws IOException {
        AnchorPane paneADD = FXMLLoader.load(getClass().getResource("Layout.fxml"));
        viewEvents.getChildren().setAll(paneADD);
    }
    
}
